#include "API_MPU.h"


/*=================================PART 1=====================================*/
/*===========================GLOBAL VARIABLES=================================*/
I2cBus i2c_bus; //variables to connect to I2C
Mpu9250 imu; //variables to connect MPU with I2C

/*============================================================================*/

/*==============STORE THE OVERALL ROTATION ANGLE OF THE SENSOR================*/
//Global variables
high_resolution_clock::time_point last_read_time;
float last_x_angle; //These are filtered angles
float last_y_angle;
float last_z_angle;
float last_gyro_x_angle; //Store gyro angle to compare drift
float last_gyro_y_angle;
float last_gyro_z_angle;
/*============================================================================*/

/*====================CALIBRATE THE ACCELERATION SENSOR=======================*/
float base_x_accel;
float base_y_accel;
float base_z_accel;

float base_x_gyro;
float base_y_gyro;
float base_z_gyro;

/*============================================================================*/
/*=================================PART 2=====================================*/
/*===============================FUNCTIONS====================================*/

/*==============================INIT MPU9250==================================*/
int init_mpu() {
    i2c_bus = I2cBus(1); //variables to connect to I2C
    imu = Mpu9250(&i2c_bus); //variables to connect MPU with I2C

    /*=========================CHECK ADDRESS==================================*/
    // Initiating communication
    uint8_t c = imu.ComTest(kWhoAmImpu6500);

    // Setup --------------------------------------------------------------------
    if (c == 0x71) { // WHO_AM_I should always be 0x71
        printf("MPU9250 is online...\n");

        imu.InitMpu9250();
        imu.GetGyroRes();
        imu.GetAccelRes();
        imu.GetMagnetomRes();

        // Read the WIA register of the magnetometer, this is a good test of
        // communication
        uint8_t d = imu.ComTest(kWia);
        if (d == 0x48) { // WHO_AM_I should always be 0x48
            printf("AK8963 is online...\n");
        } else {
            perror("Could not connect to AK8963");
            return 1;
        }
        /*=========================PRE-PROCESSING=============================*/
        calibrate_sensors();
        set_last_read_angle_data(get_current_time(), 0, 0, 0, 0, 0, 0);
        /*====================================================================*/
    } else {
        perror("Could not connect to MPU9250");
        return 1;
    }

    return 0;
}
/*============================================================================*/

/*========================SET THE LATEST TAKEN DATA===========================*/
void set_last_read_angle_data(high_resolution_clock::time_point time,
                              float x, float y, float z,
                              float x_gyro, float y_gyro, float z_gyro) {
    last_read_time = time;
    last_x_angle = x;
    last_y_angle = y;
    last_z_angle = z;

    last_gyro_x_angle = x_gyro;
    last_gyro_y_angle = y_gyro;
    last_gyro_z_angle = z_gyro;
}
/*============================================================================*/

/*=======================FUNCTIONS TO GET CALIBRATED DATA=====================*/
inline high_resolution_clock::time_point get_last_time() {
    return last_read_time;
}

inline float get_last_x_angle() {
    return last_x_angle;
}

inline float get_last_y_angle() {
    return last_y_angle;
}

inline float get_last_z_angle() {
    return last_z_angle;
}

inline float get_last_gyro_x_angle() {
    return last_gyro_x_angle;
}

inline float get_last_gyro_y_angle() {
    return last_gyro_y_angle;
}

inline float get_last_gyro_z_angle() {
    return last_gyro_z_angle;
}
/*============================================================================*/

/*==============================READ RAW DATA=================================*/
void read_gyro_accel_vals(float* accel_t_gyro_ptr) {
    uint8_t data;
    i2c_bus.ReadFromMem(kMpu6500Addr, kIntStatus, &data);
    Accel_T_Gyro_union* accel_t_gyro = (Accel_T_Gyro_union*) accel_t_gyro_ptr;

    if (data == 0x01) {

        imu.ReadAccelData(imu.accel_count); // Read the x/y/z adc values
        // Now we'll calculate the acceleration value into actual g's
        // This depends on scale being set
        imu.accel_x = (float) imu.accel_count[0] * imu.accel_res;
        imu.accel_y = (float) imu.accel_count[1] * imu.accel_res;
        imu.accel_z = (float) imu.accel_count[2] * imu.accel_res;

        imu.ReadGyroData(imu.gyro_count); // Read the x/y/z adc values
        // Calculate the gyro value into actual degrees per second
        // This depends on scale being set
        imu.gyro_x = (float) imu.gyro_count[0] * imu.gyro_res;
        imu.gyro_y = (float) imu.gyro_count[1] * imu.gyro_res;
        imu.gyro_z = (float) imu.gyro_count[2] * imu.gyro_res;

        imu.ReadMagnetomData(imu.magnetom_count); // Read the x/y/z adc values
        // Get actual magnetometer value, this depends on scale being set
        imu.magnetom_x = (float) imu.magnetom_count[0] * imu.magnetom_res;
        imu.magnetom_y = (float) imu.magnetom_count[1] * imu.magnetom_res;
        imu.magnetom_z = (float) imu.magnetom_count[2] * imu.magnetom_res;


        /*======================PRE-PROCESSING================================*/
        accel_t_gyro->value.x_accel = imu.accel_x;
        accel_t_gyro->value.y_accel = imu.accel_y;
        accel_t_gyro->value.z_accel = imu.accel_z;

        accel_t_gyro->value.x_gyro = imu.gyro_x;
        accel_t_gyro->value.y_gyro = imu.gyro_y;
        accel_t_gyro->value.z_gyro = imu.gyro_z;

        accel_t_gyro->value.x_mag = imu.magnetom_x;
        accel_t_gyro->value.y_mag = imu.magnetom_y;
        accel_t_gyro->value.z_mag = imu.magnetom_z;
        /*====================================================================*/
    }
}
/*============================================================================*/

/*============================SET BASE DATA===================================*/
// The sensor should be motionless on a horizontal surface
//  while calibration is happening

void calibrate_sensors() {
    int num_of_times = 100;
    float x_accel = 0;
    float y_accel = 0;
    float z_accel = 0;
    float x_gyro = 0;
    float y_gyro = 0;
    float z_gyro = 0;
    Accel_T_Gyro_union accel_t_gyro;
    // Discard the first set of values read from the IMU
    read_gyro_accel_vals((float*) &accel_t_gyro);
    for (int i = 0; i < num_of_times; i++) {
        read_gyro_accel_vals((float*) &accel_t_gyro);
        x_accel += accel_t_gyro.value.x_accel;
        y_accel += accel_t_gyro.value.y_accel;
        z_accel += accel_t_gyro.value.z_accel;
        x_gyro += accel_t_gyro.value.x_gyro;
        y_gyro += accel_t_gyro.value.y_gyro;
        z_gyro += accel_t_gyro.value.z_gyro;
    }

    x_accel /= num_of_times;
    y_accel /= num_of_times;
    z_accel /= num_of_times;
    x_gyro /= num_of_times;
    y_gyro /= num_of_times;
    z_gyro /= num_of_times;

    // Store the raw calibration values globally
    base_x_accel = x_accel;
    base_y_accel = y_accel;
    base_z_accel = z_accel;

//    base_x_gyro = x_gyro;
//    base_y_gyro = y_gyro;
//    base_z_gyro = z_gyro;
}
/*============================================================================*/

/*======================GET CURRENT TIME IN MILLISECOND=======================*/
high_resolution_clock::time_point get_current_time() {
    high_resolution_clock::time_point hrcTime;

    hrcTime = high_resolution_clock::now();
    return hrcTime;
}
/*============================================================================*/

/*=======================GET CURRENT TIME IN SECOND===========================*/
float get_real_time_span(high_resolution_clock::time_point tFirst,
                         high_resolution_clock::time_point tSecond) {
    duration<double> time_span_2 = tSecond - tFirst;

    return time_span_2.count();
}
/*============================================================================*/

/*==========================UTILITY FUNCTIONS=================================*/
std::vector<float> get_accel_three_axis() {
    std::vector<float> results;


    int max_of_repeat = 10;
    int loop = 0;

    while(true) {
        double dT;
        Accel_T_Gyro_union accel_t_gyro;
        read_gyro_accel_vals((float*) &accel_t_gyro);

        high_resolution_clock::time_point t_now = get_current_time();

        // Get raw acceleration values
        //float G_CONVERT = 16384;
        float accel_x = accel_t_gyro.value.x_accel * 9.8;
        float accel_y = accel_t_gyro.value.y_accel * 9.8;
        float accel_z = accel_t_gyro.value.z_accel * 9.8;

        if(loop == max_of_repeat) {
            results.push_back(accel_x);
            results.push_back(accel_y);
            results.push_back(accel_z);
            break;
        }
        loop++;
    }


    return results;
}

std::vector<float> get_gyro_three_axis() {
    std::vector<float> results;


    int max_of_repeat = 50;
    int loop = 0;

    while(true) {
        double dT;
        Accel_T_Gyro_union accel_t_gyro;
        read_gyro_accel_vals((float*) &accel_t_gyro);

        high_resolution_clock::time_point t_now = get_current_time();

        // Convert gyro values to degrees/sec
        float FS_SEL = 131;

        float gyro_x = (accel_t_gyro.value.x_gyro - base_x_gyro) / FS_SEL;
        float gyro_y = (accel_t_gyro.value.y_gyro - base_y_gyro) / FS_SEL;
        float gyro_z = (accel_t_gyro.value.z_gyro - base_z_gyro) / FS_SEL;


        // Get raw acceleration values
        //float G_CONVERT = 16384;
        float accel_x = accel_t_gyro.value.x_accel;
        float accel_y = accel_t_gyro.value.y_accel;
        float accel_z = accel_t_gyro.value.z_accel;

        // Get angle values from accelerometer
        float RADIANS_TO_DEGREES = 180 / 3.14159;
        //Float accel_std::vector_length = sqrt(pow(accel_x,2) + pow(accel_y,2) + pow(accel_z,2));
        float accel_angle_y = atan(-1 * accel_x / sqrt(pow(accel_y, 2) + pow(accel_z, 2))) * RADIANS_TO_DEGREES;
        float accel_angle_x = atan(accel_y / sqrt(pow(accel_x, 2) + pow(accel_z, 2))) * RADIANS_TO_DEGREES;

        float accel_angle_z = 0;

        // Compute the (filtered) gyro angles
        float dt = get_real_time_span(get_last_time(), t_now);
        float gyro_angle_x = gyro_x * dt + get_last_x_angle();
        float gyro_angle_y = gyro_y * dt + get_last_y_angle();
        float gyro_angle_z = gyro_z * dt + get_last_z_angle();

        // Compute the drifting gyro angles
        float unfiltered_gyro_angle_x = gyro_x * dt + get_last_gyro_x_angle();
        float unfiltered_gyro_angle_y = gyro_y * dt + get_last_gyro_y_angle();
        float unfiltered_gyro_angle_z = gyro_z * dt + get_last_gyro_z_angle();

        // Apply the complementary filter to figure out the change in angle - choice of alpha is
        // estimated now.  Alpha depends on the sampling rate...
        float alpha = 0.96;
        float angle_x = alpha * gyro_angle_x + (1.0 - alpha) * accel_angle_x;
        float angle_y = alpha * gyro_angle_y + (1.0 - alpha) * accel_angle_y;
        float angle_z = gyro_angle_z; //Accelerometer doesn't give z-angle

        // Update the saved data with the latest values
        set_last_read_angle_data(t_now,
                                 angle_x, angle_y, angle_z,
                                 unfiltered_gyro_angle_x, unfiltered_gyro_angle_y, unfiltered_gyro_angle_z);

        if(loop == max_of_repeat) {
            angle_x -= base_x_gyro;
            angle_y -= base_y_gyro;
            angle_z -= base_z_gyro;
            results.push_back(angle_x);
            results.push_back(angle_y);
            results.push_back(angle_z);
            break;
        }
        loop++;
    }


    return results;
}

std::vector<float> get_mag_three_axis() {
    std::vector<float> results;


    int max_of_repeat = 10;
    int loop = 0;

    while(true) {
        double dT;
        Accel_T_Gyro_union accel_t_gyro;
        read_gyro_accel_vals((float*) &accel_t_gyro);

        high_resolution_clock::time_point t_now = get_current_time();

        // Get raw acceleration values
        //float G_CONVERT = 16384;
        float mag_x = accel_t_gyro.value.x_mag * 9.8;
        float mag_y = accel_t_gyro.value.y_mag * 9.8;
        float mag_z = accel_t_gyro.value.z_mag * 9.8;

        if(loop == max_of_repeat) {
            results.push_back(mag_x);
            results.push_back(mag_y);
            results.push_back(mag_z);
            break;
        }
        loop++;
    }


    return results;
}
/*============================================================================*/
