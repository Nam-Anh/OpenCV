#ifndef API_MPU_H
#define API_MPU_H

#include <iostream> // Needed for cout
#include <ctime>    // Needed for get time
#include <ratio>
#include <chrono>   //Needed for get current time in miliseconds
#include <math.h>   //Needed for using pow()
#include <stdio.h>  // Needed for printf, snprintf, perror
#include <stdint.h>  // Needed for unit uint8_t data type
#include <stdlib.h>  // Needed for exit()
#include <vector> //Needed for std::vector
#include "I2C/i2c.h"
#include "MPU/mpu9250.h"

using namespace std::chrono;
using namespace std;
/*=================================PART 1=====================================*/
/*===========================GLOBAL VARIABLES=================================*/
extern I2cBus i2c_bus; //variables to connect to I2C
extern Mpu9250 imu; //variables to connect MPU with I2C

/*============================================================================*/

/*==============STORE THE OVERALL ROTATION ANGLE OF THE SENSOR================*/
//Global variables
extern high_resolution_clock::time_point last_read_time;
extern float last_x_angle; //These are filtered angles
extern float last_y_angle;
extern float last_z_angle;
extern float last_gyro_x_angle; //Store gyro angle to compare drift
extern float last_gyro_y_angle;
extern float last_gyro_z_angle;
/*============================================================================*/

/*====================CALIBRATE THE ACCELERATION SENSOR=======================*/
extern float base_x_accel;
extern float base_y_accel;
extern float base_z_accel;

extern float base_x_gyro;
extern float base_y_gyro;
extern float base_z_gyro;

/*============================================================================*/

/*=========================Define struct for data=============================*/
union Accel_T_Gyro_union {

    struct {
        float x_accel;
        float y_accel;
        float z_accel;
        float x_gyro;
        float y_gyro;
        float z_gyro;
        float x_mag;
        float y_mag;
        float z_mag;
    } value;
} ;
/*============================================================================*/

/*=================================PART 2=====================================*/
/*===============================FUNCTIONS====================================*/

/*========================INIT MPU9250===========================*/
int init_mpu();
/*============================================================================*/

/*========================SET THE LATEST TAKEN DATA===========================*/
void set_last_read_angle_data(high_resolution_clock::time_point time,
        float x, float y, float z,
        float x_gyro, float y_gyro, float z_gyro);

/*=======================FUNCTIONS TO GET CALIBRATED DATA=====================*/
inline high_resolution_clock::time_point get_last_time();

inline float get_last_x_angle();
inline float get_last_y_angle();
inline float get_last_z_angle();

inline float get_last_gyro_x_angle();
inline float get_last_gyro_y_angle();
inline float get_last_gyro_z_angle();
/*============================================================================*/

/*==============================READ RAW DATA=================================*/
void read_gyro_accel_vals(float* accel_t_gyro_ptr);
/*============================================================================*/

/*============================SET BASE DATA===================================*/
// The sensor should be motionless on a horizontal surface
//  while calibration is happening
void calibrate_sensors();
/*============================================================================*/

/*======================GET CURRENT TIME IN MILLISECOND=======================*/
high_resolution_clock::time_point get_current_time();
/*============================================================================*/

/*=======================GET CURRENT TIME IN SECOND===========================*/
float get_real_time_span(high_resolution_clock::time_point tFirst,
                        high_resolution_clock::time_point tSecond);
/*============================================================================*/

/*==========================UTILITY FUNCTIONS=================================*/
std::vector<float> get_accel_three_axis();  //Get acceleration along 3 axises
std::vector<float> get_gyro_three_axis();   //Get gyro along 3 axises
std::vector<float> get_mag_three_axis();    //Get magneto along 3 axises
/*============================================================================*/

/*============================================================================*/
#endif /* API_MPU_H */

