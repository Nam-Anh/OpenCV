#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <fstream>
using namespace std;
using namespace cv;

/*Global variables*/

/*----------------*/

/*Supported functions*/
std::string base_name(std::string const & path) {
    return path.substr(path.find_last_of("/\\") + 1);
}

/*-------------------*/
int main(int argc, char** argv) {
    //    //Read file if need
    //    string text;
    //    fstream myfile;
    //    myfile.open ("");
    //    for(int i = 0; i < 11; i++)
    //        for(int j = 0; j < 11; j++){
    //            myfile >> src.at<float>(j,i);
    //        }
    //    myfile.close();
    //    /*------------------------------------------------------------------------*/
    Mat src, dst;
    VideoCapture cap;

    string file = "";
    src = imread(file, IMREAD_COLOR);
    if (src.empty()) {
        cerr << endl << "Error loading image" << endl;
        return -1;
    }
    /*------------------------------------------------------------------------*/
    namedWindow("src", WINDOW_AUTOSIZE);
    imshow("src", src);
    namedWindow("dst", WINDOW_AUTOSIZE);
    imshow("dst", dst);
    /*------------------------------------------------------------------------*/
    //    file = "updated"+base_name(file);
    //    imwrite(file,dst);
    waitKey(0);
    return 0;
}