#include "API_MPU.h"
#include <fstream>
#include <string>
int main() {


    int success = init_mpu();
    if (success != 0) {
        cout << "Can not connect to MPU" << endl;
        return 1;
    }

    std::string input;
    std::ofstream out("output.txt");



    while (true) {
//        vector<float> rs = get_gyro_three_axis();
        vector<float> rs = get_accel_three_axis();
        input = "x, y, z: ";
        for (int i = 0; i < rs.size(); i++) {
            input = input + to_string(rs[i]) + "," ;
        }
        input += "\n";
        out << input;
    }

    out.close();
    return 0;
}
