#include "cam_interact/camera_controller.h"
#include "traffic/traffic_sign.h"
//#include "traffic_sign/traffic_sign_recognition.h"
#include "driving_control/driving_controller.h"
#include "GPIO/gpio_controller.h"
#include "video_logger/video_logger.h"

#include "DepthSource/depthTryHard.h"
#include "minhcht_lane_detection/laneDetectv2.h"
#include "MPU/MPU.h"


#include <thread>

/*Define section */

#define LOG_COLOR true
#define LOG_GRAY false
#define SHOW_LANE false
#define SHOW_COLOR false
#define SHOW_OBJECT_DEBUG false
#define SHOW_DEPTH false
#define USING_MPU true
#define SHOW_CAFFE_RECOGNITION 0
#define STOP_MOD 2

#define OFF 0
#define CAFFE 1
#define DEPTH 2
#define DLIB 3

#define OBJECT_MODE DEPTH
#define TRAFFIC_SIGN_MODE DLIB

Mat current_frame;
int is_continue = 1;
double global_steering_angle = 0;
int global_label = -1;
int sign_label = -1;
bool has_cross = false;
int bt_status = 0;
bool thread_status = true;
Rect global_object_rect(-1,-1,1,1);
Mat depth_frame;
ofstream filestream;
bool has_object = false;
#if LOG_COLOR || LOG_GRAY
bool ready_to_log = false;
#endif // LOG_COLOR
float flip_angle = 0;
std::vector<double> compass(3);

Mat color_frame;
Mat gray_frame;

int stop_height = -1;
int count_stop = 0;

void read_frame() {
    while(is_continue) {
        current_frame = get_color_frame();
    }
}

void read_depth() {
    while(is_continue) {
        depth_frame = get_depth_frame();
    }
}

void control_engine() {
    while (is_continue) {
        is_continue = control_car(global_steering_angle, global_label, bt_status, has_object, flip_angle);
    }
}

#if USING_MPU
void thread_get_mpu_data(){
    while (is_continue){
        RTIMU_DATA data = get_mpu_data();
        if (data.fusionPoseValid){
            flip_angle = data.fusionPose.x() * RTMATH_RAD_TO_DEGREE;
        }

        if (data.compassValid){
            RTVector3 compass_data = data.compass;
            compass[0] = compass_data.x();
            compass[1] = compass_data.y();
            compass[2] = compass_data.z();
        }
    }
}
#endif // USING_MPU

#if LOG_COLOR || LOG_GRAY
void log_video() {
    #if LOG_COLOR
    Mat color;
    #endif // LOG_COLOR
    #if LOG_GRAY
    Mat gray;
    #endif // LOG_GRAY

    while (is_continue) {
        if (ready_to_log) {
            #if LOG_COLOR
            color_frame.copyTo(color);
            log_color(color);
            #endif // LOG_COLOR
            #if LOG_GRAY
            gray_frame.copyTo(gray);
            log_gray(gray);
            #endif // LOG_GRAY
            waitKey(15);
        } else {
            waitKey(2);
        }
    }
}
#endif // LOG_VIDEO



#if TRAFFIC_SIGN_MODE == DLIB

void thread_get_left_right_label() {
    Mat traffic_frame;
    int label;
    while (is_continue) {
        if (current_frame.empty()){
            continue;
        }
        traffic_frame = current_frame(Rect(0, 0, 640, 240));
        label = get_left_right_label(traffic_frame, false);
        if (label == 0 || label == 1) {
            global_label = label;
        }
    }
}

void thread_stop_sign() {
    Mat traffic_frame;
    std::vector<rect_detection> stop_sign;
    while (is_continue) {
//        double start = getTickCount();
        int height = -1;
        if (current_frame.empty()){
            continue;
        }
        traffic_frame = current_frame(Rect(0, 0, 640, 240));
        stop_sign = get_stop_sign(traffic_frame, false);
        for (int i = 0; i < stop_sign.size(); ++i) {
            int tmp_height = stop_sign[i].rect.height() / 2;
            if (tmp_height > height) {
                height = tmp_height;
            }
        }
        if (height == -1) {
            ++count_stop;
            if (count_stop > 10) {
                stop_height = height;
                count_stop = 0;
            }
        } else {
            stop_height = height;
            count_stop = 0;
        }
//        double end = getTickCount();
//        cout << "FPS ====: " << getTickFrequency() / (end - start) << endl;
    }
}

#elif TRAFFIC_SIGN_MODE == CAFFE

void thread_traffic_sign() {
    std::vector<int> labels;
    Mat traffic_frame;
    Rect object_rect;

    Caffe::set_mode(Caffe::GPU);
    while (is_continue) {
        if(current_frame.cols == 0)
            continue;

        int height = -1;
        double start = getTickCount();

//        =================CODE CAFFE==========================
        resize(current_frame, traffic_frame, Size(320, 240));
        std::vector<Label_Area> vec_label_area = evaluate_frame(traffic_frame, SHOW_CAFFE_RECOGNITION);
        Label_Area left_right = vec_label_area[0];
        Label_Area stop = vec_label_area[1];
        Label_Area object = vec_label_area[2];
        global_label = left_right.first;
        if(stop.first == -1) {
            stop_height = -1;
        } else {
            stop_height = stop.second.height;
        }

        global_object_rect = object.second;
        double end = getTickCount();
        //cout << "FPS Caffe ====: " << getTickFrequency() / (end - start) << endl;
    }
}

#endif // TRAFFIC_SIGN_MODE



void run_video(int init_throttle, string video_file) {
    /*Init Component*/
    init_engine(init_throttle);
    init_gpio();
    VideoCapture cap(video_file);
    /*End init component*/

    /*Init thread*/
    Mat frame;
    Mat gray;
    cap >> current_frame;

#if TRAFFIC_SIGN_MODE == DLIB
    init_traffic_sign_detection();
    std::thread left_right_thread(thread_get_left_right_label);
    std::thread stop_thread(thread_stop_sign);
#elif TRAFFIC_SIGN_MODE == CAFFE
    std::thread thread_traffic(thread_traffic_sign);
#endif // TRAFFIC_SIGN_MODE

    while (true) {
        //get peripheral signal (button, key)
        int status = get_current_value();
        current_frame.copyTo(frame);
#if OBJECT_MODE == CAFFE
        Rect object_rect = global_object_rect;
#else
        Rect object_rect = Rect(-1,-1,1,1);
#endif

         //=======================TRAFFIC SIGN===============================
        double angle = 0;
        if (global_label == 0 ||global_label == 1) {
            sign_label = global_label;
//            cout <<"sign_label: "<<sign_label<< endl;
        }
        //==================**************************======================


        //======================LANE DETECTION==============================
        //============= return angle in degree ==================
        if (sign_label == 1 || sign_label == 0) {
            angle = angleValCalVisual(has_object,object_rect,true, sign_label, frame, gray) * 4.5;

        } else {
            angle = angleValCalVisual(has_object,object_rect,true, 0, frame, gray) * 4.5;
        }

        //====================**********************=========================


        //============================ ENGINE INTERACT =======================
        bt_status = status;
        global_steering_angle = angle;
        is_continue = control_car(global_steering_angle, stop_height, bt_status, has_object, flip_angle);

        //=========================*********************=======================


        //=============================== VISUAL =======================================
        // ================color frame===================
        putText(frame, std::to_string(sign_label), Point(100, 100),  FONT_HERSHEY_SIMPLEX, 1, Scalar(0, 0, 255), 2, 8, false);

#if SHOW_COLOR
        imshow("color", frame);
#endif // SHOW_COLOR

#if SHOW_LANE
        imshow("Lane", gray);
#endif // SHOW_LANE
        //===============================================

        //==========================*******************************======================
        //================================ LOG ANGLE ======================================
        filestream << global_steering_angle << endl;
        //==============================***************==================================

        if (!is_continue) {
            break;
        }
        waitKey(1);

        cap >> current_frame;
    }


}

void run_from_cam(int init_throttle) {
    //===================Init Component==========================
    init_engine(init_throttle);
    init_device();
    init_color_stream();
    init_gpio();
#if USING_MPU
    init_mpu();
#endif // USING_MPU

#if OBJECT_MODE == DEPTH
    init_depth_stream();
    Mat depth;
    depth_frame = get_depth_frame();
    std::thread read_depth_frame(read_depth);
#endif // OBJECT_MODE

    //====================***************========================

    Mat frame;
    Mat gray;
    current_frame = get_color_frame();

    //=======================Init thread============================

#if TRAFFIC_SIGN_MODE == DLIB
    init_traffic_sign_detection();
    std::thread left_right_thread(thread_get_left_right_label);
    std::thread stop_thread(thread_stop_sign);
#elif TRAFFIC_SIGN_MODE == CAFFE
    std::thread thread_traffic(thread_traffic_sign);
#endif // TRAFFIC_SIGN_MODE

    std::thread read_color_frame(read_frame);

#if LOG_COLOR || LOG_GRAY
    std::thread thead_log_video(log_video);
#endif // LOG_VIDEO

#if USING_MPU
    std::thread thread_mpu(thread_get_mpu_data);
#endif // USING_MPU
    //=====================****************==========================


    //=======================MAIN FLOW=================================
    while (true) {
        double start = getTickCount();

        //get peripheral signal (button, key)
        int status = get_current_value();

        //copy value of global variable to this frame to process
#if LOG_VIDEO
        ready_to_log = false;
#endif // LOG_VIDEO
        current_frame.copyTo(frame);
        //======================OBJECT PROCESS===========================
#if OBJECT_MODE == OFF
        Rect object_rect = Rect(-1,-1,1,1);
#elif OBJECT_MODE == DEPTH
        depth_frame.copyTo(depth);
        Rect object_rect = objectDetectTryHard(SHOW_OBJECT_DEBUG, depth);
#elif OBJECT_MODE == CAFFE
        Rect object_rect = global_object_rect;
#endif

        //=======================TRAFFIC SIGN===============================
        double angle = 0;
        if (global_label == 0 ||global_label == 1) {
            sign_label = global_label;
//            cout <<"sign_label: "<<sign_label<< endl;
        }
        //==================**************************======================


        //======================LANE DETECTION==============================
        //============= return angle in degree ==================
        if (sign_label == 1 || sign_label == 0) {
            angle = angleValCalVisual(has_object,object_rect,true, sign_label, frame, gray) * 3.7;

        } else {
            angle = angleValCalVisual(has_object,object_rect,true, 0, frame, gray) * 3.7;
        }

        //====================**********************=========================


        //============================ ENGINE INTERACT =======================
        bt_status = status;
        global_steering_angle = angle;
        float flip = flip_angle;
        std::vector<double> current_compass = compass;
        //cout << compass[0] << "\t" << compass[1] << "\t" << compass[2] << endl;
        #if STOP_MOD == 1
        is_continue = control_car(global_steering_angle, current_compass, sign_label, bt_status, has_object, flip);
        #elif STOP_MOD == 0 // STOP_USING_MPU
        is_continue = control_car(global_steering_angle, stop_height, bt_status, has_object, flip);
        #elif STOP_MOD == 2 // STOP_USING_MPU
        is_continue = control_car(global_steering_angle, stop_height, current_compass, sign_label, bt_status, has_object, flip);
        #endif // STOP_MOD
        //=========================*********************=======================


        //=============================== VISUAL =======================================
        // ================color frame===================
//        putText(frame, std::to_string(sign_label), Point(100, 100),  FONT_HERSHEY_SIMPLEX, 1, Scalar(0, 0, 255), 2, 8, false);
        putText(frame, std::to_string(compass[0]) + "  " + std::to_string(compass[1]) + "   " + std::to_string(compass[2]),
                Point(100, 100), FONT_HERSHEY_COMPLEX, 1, Scalar(0, 0, 255), 2, 8, false);
#if SHOW_COLOR
        imshow("color", frame);
#endif // SHOW_COLOR

#if SHOW_DEPTH && OBJECT_MODE == DEPTH
        imshow("Depth", depth);
#endif // SHOW_DEPTH

#if SHOW_LANE
        imshow("Lane", gray);
#endif // SHOW_LANE
        //===============================================

        //==========================*******************************======================
        #if LOG_COLOR
        frame.copyTo(color_frame);
        ready_to_log = true;
        #endif // LOG_COLOR
        #if LOG_GRAY
        gray.copyTo(gray_frame);
        ready_to_log = true;
        #endif // LOG_GRAY

        //================================ LOG ANGLE ======================================
        filestream << global_steering_angle << endl;
        //==============================***************==================================

        if (!is_continue) {
            break;
        }

        waitKey(1);
        double end = getTickCount();
        double fps = getTickFrequency()/(end-start);
//        cout<<"Main FPS: "<<fps<<endl;
    }

    //========================Release component=========================
    release_video_writer();
    camera_release();
    //========================******************========================
}

int main(int argc, char* argv[]) {

    if(argc < 3) {
        cout << "Please enter mode" <<endl;
        return 0;
    }
    filestream.open("log.txt");

    int init_throttle = atoi(argv[1]);
    int init_mode = atoi(argv[2]);

    if(init_mode == 0) {
        run_from_cam(init_throttle);
    } else if (init_mode == 1 && argc > 3){
        run_video(init_throttle, argv[3]);
    } else {
        cout << "Please enter correct mode" << endl;
    }
    cout << "END" << endl;
    filestream.close();
    return 0;
}


