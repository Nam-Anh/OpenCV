#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <fstream>
#include <set>
#include <algorithm>
#include <stdlib.h>
#include <bits/c++config.h>

using namespace std;
using namespace cv;

Mat ROI(Mat src, int vect[]){
    Mat roi;
    roi = src(Rect(vect[0], vect[1], vect[2], vect[3]));
    return roi;
}
Rect boundingObj(Mat input){
    Rect res;
    res.x = -1;
    vector<vector<Point> > cnts;
    findContours(input,cnts,CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));
    int max = -1;
    int maxPos = -1;
    int cntsN = cnts.size();
    if (cntsN == 0){
        return res;
    }
    for (int i =0; i < cntsN; i++){
        if (max < contourArea(cnts[i])){
            max = contourArea(cnts[i]);
            maxPos = i;
        }
    }
    if (max < 10){
        return res;
    }
    res = boundingRect(cnts[maxPos]);
    return res;
}
Mat distanceFilter(Mat input){
    int vect[] = {0,0,320,160};
    input = ROI(input,vect);
//    cvtColor(input,input,CV_RGB2GRAY);
//    threshold(input,input,90,255,THRESH_TOZERO_INV);
//    threshold(input,input,1,255,THRESH_TOZERO);
    inRange(input,1,40,input);
    return input;
}
Rect objectDetectTryHard(bool isTesting,Mat input){
    input = distanceFilter(input);
    if (isTesting){
        imshow("CHECK",input);
    }
    Rect objectBounded = boundingObj(input);
    objectBounded.height = objectBounded.width/2;
    objectBounded.x -= 15;
    objectBounded.x = objectBounded.x/2;
    objectBounded.y = objectBounded.y/2;
    objectBounded.width = objectBounded.width/2;
    return objectBounded;
}
