#ifndef DEPTHTRYHARD_H
#define DEPTHTRYHARD_H
Mat ROI(Mat src, int vect[]);
Rect boundingObj(Mat input);
Mat distanceFilter(Mat input);
Rect objectDetectTryHard(bool isTesting,Mat input);

#endif /* DEPTHTRYHARD_H */
