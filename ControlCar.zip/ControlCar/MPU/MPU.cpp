#include "MPU.h"

RTIMUSettings *settings = new RTIMUSettings("RTIMULib");
RTIMU *imu = RTIMU::createIMU(settings);

void init_mpu() {
    if ((imu == NULL) || (imu->IMUType() == RTIMU_TYPE_NULL)) {
        printf("No IMU found\n");
        return;
    }
    imu->IMUInit();

    //  this is a convenient place to change fusion parameters

    imu->setSlerpPower(0.02);
    imu->setGyroEnable(true);
    imu->setAccelEnable(true);
    imu->setCompassEnable(true);

}

RTIMU_DATA get_mpu_data() {
    usleep(imu->IMUGetPollInterval() * 1000);
    RTIMU_DATA imuData;
    imuData.compassValid = false;
    imuData.fusionPoseValid = false;
    if (imu->IMURead()) {
        imuData = imu->getIMUData();
    }
    return imuData;
}
