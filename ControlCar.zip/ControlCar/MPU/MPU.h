#ifndef MPU_H_INCLUDED
#define MPU_H_INCLUDED

#include "RTIMULib.h"

extern RTIMUSettings *settings;
extern RTIMU *imu;

void init_mpu();
RTIMU_DATA get_mpu_data();



#endif // MPU_H_INCLUDED
