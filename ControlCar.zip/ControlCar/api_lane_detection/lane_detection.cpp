#include "lane_detection.h"
#include "lane_utils.h"

Point preCenter(WIDTH/2, HEIGHT*2/5);
double steering_angle;
double halfRoadWidth = WIDTH*2/5;

/*Support functions*/
int laneSlope(Mat src) {
    Mat dst = Mat::zeros(src.size(), CV_8UC1);
    cvtColor(src, dst, COLOR_BGR2GRAY);
    /*Detect on two halves of frame */
    Mat firstHalf, secondHalf;
//    cout<<endl<<"size: "<<src.rows<<endl;
//    //ROI
//    Point offset = Point(0, 30);
//    int vect[] = {offset.x, offset.y, dst.cols / 2 - offset.x, dst.rows - offset.y};
//    dst = ROI(dst, vect);
    //Second ROI to divide the frame into 2 parts
    //First Half
    Point offsetF = Point(0, 0);
    int vectFirst[] = {offsetF.x, offsetF.y, dst.cols / 2, dst.rows};
    firstHalf = ROI(dst, vectFirst);

    //Second Half
    Point offsetS = Point(firstHalf.cols, 0);
    int vectSecond[] = {offsetS.x, offsetS.y, dst.cols - firstHalf.cols, dst.rows};
    secondHalf = ROI(dst, vectSecond);

    /*Contour processing*/
    /*Variable for contour processing*/
    vector<vector<Point> > firstContours, secondContours;
    vector<Point> firstGroup, secondGroup;
    Vec4f f, s;
    int alphaF, alphaS;
    alphaF = 0;
    alphaS = 0;
    /*-------------------------------*/

    /*Contours Processing*/
    firstContours = contoursGet(firstHalf);
    secondContours = contoursGet(secondHalf);
    /*-------------------------------*/

    /*Contours group*/
    if (firstContours.size() != 0) {
        firstGroup = contourFilter(firstContours);
    }
    if (secondContours.size() != 0) {
        secondGroup = contourFilter(secondContours);
    }
    /*-------------------------------*/

    /*Fit Line*/
    if (firstGroup.size() != 0) {
        f = lineGet(firstGroup);
        alphaF = (int) getSlope(f);
    }
    if (secondGroup.size() != 0) {
        s = lineGet(secondGroup);
        s[2] = s[2] + firstHalf.cols;
        s[3] = s[3];
        alphaS = (int) getSlope(s);
    }
    /*-------------------------------*/

    if (alphaF >= 0 && alphaS >= 0) {
        return 1;
    } else if (alphaF <= 0 && alphaS <= 0) {
        return -1;
    } else if ((alphaF <= 0 && alphaS >= 0) || (alphaF >= 0 && alphaS <= 0)) {
        return 2;
    } else {
        return 0;
    }
    return 0;
}
double getTheta(Point car, Point dst) {
    if (dst.x == car.x) return 0;
    if (dst.y == car.y) return (dst.x < car.x ? -90 : 90);
    double pi = acos(-1.0);
    double dx = dst.x - car.x;
    double dy = car.y - dst.y; // image coordinates system: car.y > dst.y
    if (dx < 0) return atan(-dx / dy) * 180 / pi;
    return -atan(dx / dy) * 180 / pi;
}

/*-----------------*/
/*Main functions*/
double lane_get_contour(Mat src) {
    Mat dst;
    dst = Mat::zeros(src.rows, src.cols, CV_8UC3);
    for (int y = 0; y < src.rows; y++)
        for (int x = 0; x < src.cols; x++) {
            if (src.at<uchar>(y, x) == 255) {
                dst.at<Vec3b>(y, x)[0] = 255;
                dst.at<Vec3b>(y, x)[1] = 255;
                dst.at<Vec3b>(y, x)[2] = 255;
            }

        }

    int y = dst.rows * 1/2;
    int leftStart, rightStart;
    leftStart = -1;
    rightStart = -1;

    Point left_start = Point(-1, -1);
    Point left_end = Point(-1, -1);
    Point right_start = Point(-1, -1);
    Point right_end = Point(-1, -1);
    Point center = Point(-1, -1);


    bool met = false;
    int count_black = 0;

    for (int x = 0; x < src.cols; x++) {
        if (src.at<uchar>(y, x) == 255 && !met) {
            left_start.x = x;
            left_start.y = y;
            met = true;
        } else if (src.at<uchar>(y, x) == 0 && met) {
            count_black++;
            if (count_black >= 10) {
                left_end.x = x - 10;
                left_end.y = y;
                met = false;
                break;
            }
        } else if (src.at<uchar>(y, x) == 255 && met) {
            count_black = 0;
        }
    }
    if (left_end.x < src.cols /2 ) {
        for (int x = left_end.x + 60; x < src.cols; x++) {
            if (src.at<uchar>(y, x) == 255) {
                right_start.x = x;
                right_start.y = y;
                break;
            }
        }
        if (right_start.x < src.cols / 2){
            right_start = Point(-1, -1);
        }

    }



    if (left_end.x != -1 && right_start.x != -1) {
        center.x = (int) (left_end.x + right_start.x) / 2;
        center.y = y;
        preCenter = center;
        if (center.x - left_end.x > 25){
            halfRoadWidth = center.x - left_end.x;
        }

    } else if (right_start.x == -1 && left_end.x != -1) {
        //Case when there is LEFT but not RIGHT
        int direction = laneSlope(dst);
        if (direction == 1) {
            /*Case when the road directs to the right
             And there is only left lane*/
            center.x = left_end.x + halfRoadWidth;
            center.y = y;
            preCenter = center;
        } else if (direction == -1) {
            /*Case when the road directs to the left
             And there is only right lane*/
            center.x = left_end.x - halfRoadWidth;
            center.y = y;
            preCenter = center;
        } else {
            /*Case when there is both lanes, but one of them is too short
             And the left or right lane can not be detected.
             However slopes of these lanes are still != 0 */
            center = preCenter;
        }
    } else {
        /*Not left and not right*/
        center = preCenter;
    }

    steering_angle = getTheta(center, Point(src.cols / 2, HEIGHT));

    return steering_angle;
}

double lane_get_contour_visual(Mat src, Mat &refFrame) {

//    resize(src, src, Size(WIDTH, HEIGHT));
//    Point offset = Point(0, HEIGHT / 3);
//    int vect[] = {offset.x, offset.y, WIDTH - offset.x, HEIGHT - offset.y};
//    //Process with the whole frame
//    src = ROI(src, vect);

    Mat dst;
    dst = Mat::zeros(src.rows, src.cols, CV_8UC3);
    for (int y = 0; y < src.rows; y++)
        for (int x = 0; x < src.cols; x++) {
            if (src.at<uchar>(y, x) == 255) {
                dst.at<Vec3b>(y, x)[0] = 255;
                dst.at<Vec3b>(y, x)[1] = 255;
                dst.at<Vec3b>(y, x)[2] = 255;
            }

        }

    int y = dst.rows * 1 / 2;
    int leftStart, rightStart;
    leftStart = -1;
    rightStart = -1;

    Point left_start = Point(-1, -1);
    Point left_end = Point(-1, -1);
    Point right_start = Point(-1, -1);
    Point right_end = Point(-1, -1);
    Point center = Point(-1, -1);


    bool met = false;
    int count_black = 0;

    for (int x = 0; x < src.cols; x++) {
        if (src.at<uchar>(y, x) == 255 && !met) {
            left_start.x = x;
            left_start.y = y;
            met = true;
        } else if (src.at<uchar>(y, x) == 0 && met) {
            count_black++;
            if (count_black >= 10) {
                left_end.x = x - 10;
                left_end.y = y;
                met = false;
                break;
            }
        } else if (src.at<uchar>(y, x) == 255 && met) {
            count_black = 0;
        }
    }

    circle(dst, left_start, 3, Scalar(255, 0, 0), 3, LINE_8);
    circle(dst, left_end, 3, Scalar(0, 255, 0), 3, LINE_8);


   if (left_end.x < src.cols /2 ) {
        for (int x = left_end.x + 60; x < src.cols; x++) {
            if (src.at<uchar>(y, x) == 255) {
                right_start.x = x;
                right_start.y = y;
                break;
            }
        }
        if (right_start.x < src.cols / 2){
            right_start = Point(-1, -1);
        }

    }

    circle(dst, right_start, 3, Scalar(0, 255, 0), 3, LINE_8);

    if (left_end.x != -1 && right_start.x != -1) {
        center.x = (int) (left_end.x + right_start.x) / 2;
        center.y = y;
        preCenter = center;
        if (center.x - left_end.x > 25){
            halfRoadWidth = center.x - left_end.x;
        }

    } else if (right_start.x == -1 && left_end.x != -1) {
        //Case when there is LEFT but not RIGHT
//        int direction = laneSlope(dst);
        if (left_end.x < preCenter.x) {//direction == 1
            /*Case when the road directs to the right
             And there is only left lane*/
            center.x = left_end.x + halfRoadWidth;
            center.y = y;
            preCenter = center;
        } else if (left_end.x > preCenter.x) {
            /*Case when the road directs to the left
             And there is only right lane*/
            center.x = left_end.x - halfRoadWidth;
            center.y = y;
            preCenter = center;
        }
//        else {
//            /*Case when there is both lanes, but one of them is too short
//             And the left or right lane can not be detected.
//             However slopes of these lanes are still != 0 */
//            center = preCenter;
//        }
    } else {
        /*Not left and not right*/
        center = preCenter;
    }
    circle(dst, center, 3, Scalar(0, 0, 255), 3, LINE_8);
    steering_angle = getTheta(center, Point(src.cols / 2, HEIGHT));
    refFrame = dst;

    return steering_angle;
}
/*--------------------------------------------------------*/
