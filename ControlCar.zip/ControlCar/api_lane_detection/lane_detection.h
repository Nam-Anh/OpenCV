#ifndef LANE_DETECTION_H
#define LANE_DETECTION_H

#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <fstream>
#include "lane_utils.h"
using namespace std;
using namespace cv;

/*Global variables*/
extern Point preCenter;
extern double steering_angle;
extern double halfRoadWidth;
/*----------------*/

/*Supported functions*/
int laneSlope(Mat src);
double getTheta(Point car, Point dst);
double lane_get_contour(Mat src);
double lane_get_contour_visual(Mat src, Mat &refFrame) ;

#endif /* LANE_DETECTION_H */

