#include "cam_interact/camera_controller.h"
#include "traffic_sign/traffic_sign_recognition.h"
#include "driving_control/driving_controller.h"
#include "GPIO/gpio_controller.h"
#include "video_logger/video_logger.h"
/*nam anh api*/
//#include "api_lane_detection/cross_detection.h"
#include "api_lane_detection/frame_processing.h"
#include "api_lane_detection/lane_detection.h"
#include "traffic_sign/traffic_sign_recognition.h"
#include "api_lane_detection/lane_utils.h"

/*-----------*/
/*minh api*/
#include "minhcht_lane_detection/minhCode.h"
/*--------*/

int sign_label = -1;

int main(int argc, char* argv[]) {
    int init_throttle = atoi(argv[1]);

    //init component
    init_engine(init_throttle);
    init_device();
    init_color_stream();
    init_depth_stream();
    init_gpio();
    init_video_writer(Size(320,240));

    while (true) {
        double start = getTickCount();
        Mat frame = get_color_frame();
        imshow("frame", frame);

        /*-------------------------------------------*/
        sign_label = evaluate_frame_visual(frame);


        /*PreProcessing*/
        Mat processed_frame = frame_processing(frame);
        Mat gray;
        /*-------------------------------------------*/
        /*Lane Processing */

        double steering_angle = lane_get_contour_visual(processed_frame, gray);
        /*End Lane Processing*/

        /*Cross processing*/
        Point offset = Point(0, 60);
        int vect[] = {offset.x, offset.y, WIDTH, HEIGHT - offset.y};


        Mat birdFrame = dyamicCrossDraw(frame);
        Mat emp = Mat::zeros(birdFrame.size(),CV_8UC1);
        birdFrame = drawLine(birdFrame,emp);


        bool has_cross = crossProcessVisual(gray, birdFrame);
        /*------------------------------------------*/

        /*Lane Detection*/

//        bool has_cross = false;
//        if (has_cross) {
//            cout<<"cross";
//            cout<<"\n";
//        }
        if(steering_angle< -0) {
            steering_angle=steering_angle*3;
        } else {
            steering_angle=steering_angle*3.9;
        }

//        if(sign_label == -1){//        }


//        gray = get_depth_frame();
//        Mat depth = get_depth_frame();
//        imshow("DEPTH", depth);
//        cout << depth.cols << " " << depth.rows << endl;

        int bt_status = get_current_value();
//        int is_continue = control_car(steering_angle, has_cross, bt_status);
        int is_continue = control_car(steering_angle , has_cross, sign_label, bt_status);

//        log_gray(depth);
        log_color(frame);

        if (!is_continue) {
            break;
        }
        waitKey(1);
        double end = getTickCount();
        double fps = getTickFrequency()/(end-start);
        cout<<endl<<fps<<endl;
    }

    release_video_writer();

    return 0;
}

