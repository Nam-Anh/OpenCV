#include "cam_interact/camera_controller.h"
#include "traffic_sign/traffic_sign_recognition.h"
#include "driving_control/driving_controller.h"
#include "GPIO/gpio_controller.h"
#include "video_logger/video_logger.h"
/*nam anh api*/
//#include "api_lane_detection/cross_detection.h"
#include "api_lane_detection/frame_processing.h"
#include "api_lane_detection/lane_detection.h"
#include "traffic_sign/traffic_sign_recognition.h"
#include "api_lane_detection/lane_utils.h"

/*-----------*/
/*minh api*/
#include "minhcht_lane_detection/minhCode.h"
/*--------*/

#include <thread>


Mat current_frame;
int is_continue = 1;
double global_steering_angle = 0;
int sign_label = -1;
bool has_cross = false;
int bt_status = 0;
bool thread_status = true;
Mat depth_frame;


void read_frame() {
    while(true) {
        current_frame = get_color_frame();
    }
}

void read_depth() {
    while(true) {
        depth_frame = get_depth_frame();
    }
}
void control_engine() {
    while (true) {
        is_continue = control_car(global_steering_angle , has_cross, sign_label, bt_status);
        //left_right = -1;
    }
}


int main(int argc, char* argv[]) {
    int init_throttle = atoi(argv[1]);

    //init component
    init_engine(init_throttle);
    init_device();
    init_color_stream();
//    init_depth_stream();
    init_gpio();
    init_video_writer(Size(160,80));

    current_frame = get_color_frame();
//    depth_frame = get_depth_frame();
    std::thread first(read_frame);

    std::thread second(control_engine);
//    std::thread third(read_depth);e
    while (true) {
        double start = getTickCount();
//        Mat frame = get_color_frame();
        Mat frame = current_frame;
        imshow("frame", frame);

        /*-------------------------------------------*/
        int status = get_current_value();

        int label = evaluate_frame_visual(frame);

        /*PreProcessing*/
        Mat processed_frame = frame_processing(frame);
        Mat gray;
        /*-------------------------------------------*/
        /*Lane Processing */
        double angle = lane_get_contour_visual(processed_frame, gray);
        imshow("Lane Detection", gray);
        /*End Lane Processing*/

        /*Cross processing*/
        Point offset = Point(0, 60);
        int vect[] = {offset.x, offset.y, WIDTH, HEIGHT - offset.y};


        Mat birdFrame = dyamicCrossDraw(frame);
        Mat emp = Mat::zeros(birdFrame.size(),CV_8UC1);
        birdFrame = drawLine(birdFrame,emp);

        bool cross = crossProcessVisual(gray, birdFrame);

        /*------------------------------------------*/

        /*Lane Detection*/

//        bool has_cross = false;
        if (cross) {
            cout<<"cross";
            cout<<"\n";
        }


//        if(sign_label == -1){//        }


//        Mat depth = get_depth_frame();
//        Mat depth = depth_frame;
//        imshow("DEPTH", depth);
//        Mat processed = findSign(depth,40,140);
//        imshow("processed",processed);
//        cout << depth.cols << " " << depth.rows << endl;


        if(angle < 0) {
            angle = angle * 2.2;
        } else {
            angle = angle * 3.5;
        }


        if (label == 0 || label == 1) {
            sign_label = label;
        }
        global_steering_angle = angle;
        has_cross = cross;
        bt_status = status;

        if (has_cross && sign_label != -1) {
//        if ((has_cross && sign_label != -1) || (has_cross && count_cross > cross_stack)) {
            cout << "Re" << endl;
            waitKey(waitkey_time);
//            sign_label = -1;
        }


//        int is_continue = control_car(steering_angle, has_cross, bt_status);
//        is_continue = control_car(global_steering_angle , has_cross, sign_label, bt_status);

//        log_gray(depth);
        log_color(frame);
        log_gray(gray);

        if (!is_continue) {
            break;
        }
        waitKey(1);
        double end = getTickCount();
        double fps = getTickFrequency()/(end-start);
//        cout<<endl<<fps<<endl;
    }

    release_video_writer();

    return 0;
}



