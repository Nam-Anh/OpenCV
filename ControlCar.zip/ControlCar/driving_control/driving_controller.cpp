#include "driving_controller.h"

PCA9685 *pca9685 = new PCA9685();

int throttle_value;
int max_throttle;
int curve_speed = 30;
int frame_id = 0;
double steer_angle;
double pre_angle = 0;
bool running;
bool manual_start;
bool barrier;
bool stopped;
bool printed = false;
int count_label = 0;
int waitkey_time = 350;
int label_stack = 100;
int hold_max_throttle;
int time_to_stop = 5;
bool wait_to_stop = false;
bool object;
int std_stop_height = 20;
int std_time_to_stop = 5;
std::queue<double> angle_queue;
int queue_size = 20;
bool queue_full = false;
float angle_flip;
std::vector<double> left_out_compass = {48, 20, 22};
std::vector<double> right_out_compass = {-15, 22, -7};
double std_compass_different = 1;
int throttle_low = 20;
//ofstream mystream;

int init_engine(int init_throttle) {
    steer_angle = 0;
    running = false;
    manual_start = false;
    stopped = false;
    barrier = true;
    api_pwm_pca9685_init( pca9685 );
    int throttle = 0;
    api_set_FORWARD_control(pca9685, throttle);
    max_throttle = init_throttle;
    hold_max_throttle = max_throttle;
    throttle_value = 25;
    cout << "Initial throttle: " << throttle_value << endl;
    cout << "Max throttle " << max_throttle << endl;
//    mystream.open("log.txt");
    return 0;
}
int control_car(double angle, int stop_height, int bt_status, bool has_object, float flip) {
    char key = getkey();
    steer_angle = angle;
    angle_flip = flip;
    if (!queue_full){
        angle_queue.push(angle);
        if (angle_queue.size() >= queue_size){
            queue_full = true;
        }
    } else {
        pre_angle = angle_queue.front();
        angle_queue.pop();
        angle_queue.push(steer_angle);
    }
//    cout << steer_angle - pre_angle << endl;
    api_set_STEERING_control(pca9685, steer_angle);
//    cout << "Area: " << stop_height << endl;
    object = has_object;

    switch (bt_status) {
    case 1:
        break;
    case 2:
        running = !running;
        printed = false;
        break;
    case 3:
        stopped = true;
        break;
    case 4:
        break;
    case 5:
        if (barrier == false) {
            cout << "Barrier: TRUE" << endl;
        }
        barrier = true;
        break;
    case 6:
        if (barrier == true) {
            cout << "Barrier: FALSE" << endl;
        }
        barrier = false;
        break;

    }

    if (key == 's') {
        running = !running;
        manual_start = !manual_start;
        printed = false;
    } else if (key == 'f') {
        stopped = true;
    }

    if (key == 'a') {
        max_throttle += 10;
    } else if (key == 'z') {
        max_throttle -= 10;
    }

    if (stopped) {
        cout << "End process" << endl;
        car_stop();
        return 0;
    }


    //==========================Stop sign processing ===========================

    if (stop_height != -1) {
        if (stop_height > std_stop_height) {
            running = false;
        } else {
            cout << "Stop" << endl;
            throttle_value = 0;
            max_throttle = 0;
            wait_to_stop = true;
        }
    } else if (!running && manual_start) {
        wait_to_stop = false;
        ++count_label;
        if (count_label > label_stack) {
            max_throttle = hold_max_throttle;
            running = true;
            count_label = 0;
        }
    }
    if (wait_to_stop && running){
        time_to_stop--;
        if (time_to_stop <= 0){
            running = false;
            wait_to_stop = false;
            cout << "Reverse" << endl;
            time_to_stop = std_time_to_stop;
            max_throttle = hold_max_throttle;
        }

    }

    //===============================****************================================


    if (running && !barrier && manual_start) {
        if (!printed) {
            cout << "ON" << endl;
            printed = true;
        }

        car_run();

        return 1;
    } else {
        if (!printed) {
            cout << "OFF" << endl;
            printed = true;
        }
        car_pause();
        return 1;
    }

}
int control_car(double angle, std::vector<double> current_compass, int label, int bt_status, bool has_object, float flip){
    char key = getkey();
    steer_angle = angle;
    angle_flip = flip;

    if (!queue_full){
        angle_queue.push(angle);
        if (angle_queue.size() >= queue_size){
            queue_full = true;
        }
    } else {
        pre_angle = angle_queue.front();
        angle_queue.pop();
        angle_queue.push(steer_angle);
    }

//    cout << steer_angle - pre_angle << endl;
    api_set_STEERING_control(pca9685, steer_angle);
//    cout << "Area: " << stop_height << endl;
    object = has_object;

    switch (bt_status) {
    case 1:
        break;
    case 2:
        running = !running;
        printed = false;
        break;
    case 3:
        stopped = true;
        break;
    case 4:
        break;
    case 5:
        if (barrier == false) {
            cout << "Barrier: TRUE" << endl;
        }
        barrier = true;
        break;
    case 6:
        if (barrier == true) {
            cout << "Barrier: FALSE" << endl;
        }
        barrier = false;
        break;

    }

    if (key == 's') {
        running = !running;
        manual_start = !manual_start;
        printed = false;
    } else if (key == 'f') {
        stopped = true;
    }

    if (key == 'a') {
        max_throttle += 10;
    } else if (key == 'z') {
        max_throttle -= 10;
    }

    if (stopped) {
        cout << "End process" << endl;
        car_stop();
        return 0;
    }


    //==========================Stop sign processing ===========================

    if (is_equal(current_compass, label)){
        running = false;
    } else if (!running && manual_start){
        ++count_label;
        if (count_label > label_stack){
            max_throttle = hold_max_throttle;
            throttle_value = 25;
            running = true;
            count_label = 0;
        }
    }

    //===============================****************================================


    if (running && !barrier && manual_start) {
        if (!printed) {
            cout << "ON" << endl;
            printed = true;
        }

        car_run();

        return 1;
    } else {
        if (!printed) {
            cout << "OFF" << endl;
            printed = true;
        }
        car_pause();
        return 1;
    }

}
int control_car(double angle, int stop_height, std::vector<double> current_compass, int label, int bt_status, bool has_object, float flip){
    char key = getkey();
    steer_angle = angle;
    angle_flip = flip;

    if (!queue_full){
        angle_queue.push(angle);
        if (angle_queue.size() >= queue_size){
            queue_full = true;
        }
    } else {
        pre_angle = angle_queue.front();
        angle_queue.pop();
        angle_queue.push(steer_angle);
    }

//    cout << steer_angle - pre_angle << endl;
    api_set_STEERING_control(pca9685, steer_angle);
//    cout << "Area: " << stop_height << endl;
    object = has_object;

    switch (bt_status) {
    case 1:
        break;
    case 2:
        running = !running;
        printed = false;
        break;
    case 3:
        stopped = true;
        break;
    case 4:
        break;
    case 5:
        if (barrier == false) {
            cout << "Barrier: TRUE" << endl;
        }
        barrier = true;
        break;
    case 6:
        if (barrier == true) {
            cout << "Barrier: FALSE" << endl;
        }
        barrier = false;
        break;

    }

    if (key == 's') {
        running = !running;
        manual_start = !manual_start;
        printed = false;
    } else if (key == 'f') {
        stopped = true;
    }

    if (key == 'a') {
        max_throttle += 10;
    } else if (key == 'z') {
        max_throttle -= 10;
    }

    if (stopped) {
        cout << "End process" << endl;
        car_stop();
        return 0;
    }


    //==========================Stop sign processing ===========================
    cout << stop_height << endl;
    if (stop_height >= 15 && max_throttle == throttle_low){
        running = false;
    }

    if (is_equal(current_compass, label)){
        max_throttle = throttle_low;
        throttle_value = throttle_low;
    } else if (!running && manual_start){
        ++count_label;
        if (count_label > label_stack){
            max_throttle = hold_max_throttle;
            throttle_value = 25;
            running = true;
            count_label = 0;
        }
    }

    //===============================****************================================


    if (running && !barrier && manual_start) {
        if (!printed) {
            cout << "ON" << endl;
            printed = true;
        }

        car_run();

        return 1;
    } else {
        if (!printed) {
            cout << "OFF" << endl;
            printed = true;
        }
        car_pause();
        return 1;
    }

}
int control_car(double angle, int bt_status) {
    char key = getkey();
    steer_angle = angle;
    api_set_STEERING_control(pca9685, steer_angle);

//    cout << steer_angle << endl;
    switch (bt_status) {
    case 1:
        break;
    case 2:
        running = !running;
        printed = false;
        break;
    case 3:
        stopped = true;
        break;
    case 4:
        break;
    case 5:
        if (barrier == false) {
            cout << "Barrier: TRUE" << endl;
        }
        barrier = true;
        break;
    case 6:
        if (barrier == true) {
            cout << "Barrier: FALSE" << endl;
        }
        barrier = false;
        break;

    }

    if (key == 's') {
        running = !running;
        printed = false;
    } else if (key == 'f') {
        stopped = true;
    }

    if (key == 'a') {
        max_throttle += 10;
    } else if (key == 'z') {
        max_throttle -= 10;
    }

    if (stopped) {
        cout << "End process" << endl;
        car_stop();
        return 0;
    }

    if (running && !barrier) {
        if (!printed) {
            cout << "ON" << endl;
            printed = true;
        }
        car_run();

        return 1;
    } else {
        if (!printed) {
            cout << "OFF" << endl;
            printed = true;
        }
        car_pause();
        return 1;
    }

}


void car_run() {
    if (throttle_value > max_throttle){
        throttle_value = max_throttle;
    }


//    steer_angle = normalize_steering_angle(steer_angle);
//    int throttle = get_speed_formula(steer_angle, throttle_value, max_throttle);
//
//    if (running){
//        if (throttle_value < max_throttle){
//            frame_id++;
//            if (frame_id % 5 == 0){
//                throttle_value++;
//            }
//        }
//    }
////
//    int throttle = (int) get_speed_interval(steer_angle, throttle_value, max_throttle, object);
//////    cout << "Throttle: " << throttle << endl;
//    api_set_FORWARD_control(pca9685, throttle);
//
/* Using get speed */

//    int throttle = (int) get_speed(pre_angle, steer_angle, throttle_value, max_throttle, curve_speed);
//    if (throttle > throttle_value){
//        ++frame_id;
//        throttle = throttle_value;
//        if (frame_id % 4 == 0){
//            throttle++;
//        }
//    }
//    throttle_value = throttle;
//    api_set_FORWARD_control(pca9685, throttle_value);

/*End using get speed */


/*Using flip_angle */
    int throttle = get_speed_using_flip(angle_flip, max_throttle);
    if (throttle > throttle_value){
        throttle = throttle_value;
        ++frame_id;
        if (frame_id % 2 == 0){
            throttle++;
        }
    }
    throttle_value = throttle;
    api_set_FORWARD_control(pca9685, throttle);

/* End using flip */

}

void car_pause() {
    int throttle = 0;
    throttle_value = 25;
    api_set_FORWARD_control(pca9685, throttle);
}

void car_stop() {
    steer_angle = 0;
    int throttle = 0;
    api_set_STEERING_control(pca9685, steer_angle);
    api_set_FORWARD_control(pca9685, throttle);
//    mystream.close();
}

bool is_equal(std::vector<double> current_compass, int current_traffic_sign){
    std::vector<double> std_compass;
    if (current_traffic_sign == 0){ //left int, left out
        std_compass = left_out_compass;
    } else {
        std_compass = right_out_compass;
    }

    if (std::abs(std_compass[0] - current_compass[0]) > std_compass_different){
        return false;
    }

    if (std::abs(std_compass[1] - current_compass[1]) > std_compass_different){
        return false;
    }

    if (std::abs(std_compass[2] - current_compass[2]) > std_compass_different){
        return false;
    }

    return true;
}
