#ifndef DRIVING_CONTROLLER_H_INCLUDED
#define DRIVING_CONTROLLER_H_INCLUDED

//include library herer
#include "peripheral_driver/api_i2c_pwm.h"
#include "fuzzy.h"
#include <opencv2/opencv.hpp>
#include <fstream>
using namespace cv;
using namespace std;


//define constant here


//declare variable here
extern PCA9685 *pca9685;
extern int throttle_value;
extern double steer_angle;
extern double pre_angle;
extern bool running;
extern bool manual_start;
extern bool barrier;
extern bool stopped;
extern bool printed;
extern int count_label;
extern int max_throttle;
extern int curve_speed;
extern int hold_max_throttle;
extern int waitkey_time;
extern int frame_id;
extern int label_stack;
extern ofstream mystream;
extern bool object;
extern int std_stop_height;
extern int std_time_to_stop;
extern std::queue<double> angle_queue;
extern int queue_size;
extern bool queue_full;
extern float flip_angle;
extern std::vector<double> left_out_compass;
extern std::vector<double> right_out_compass;
extern double std_compass_different;
extern int throttle_low;
//declare function prototype here
int init_engine(int init_throttle);
int control_car(double angle, int stop_height, int bt_status, bool has_object, float flip);
int control_car(double angle, std::vector<double> current_compass, int label, int bt_status, bool has_object, float flip);
int control_car(double angle, int stop_height, std::vector<double> current_compass, int label, int bt_status, bool has_object, float flip);
int control_car(double angle, int bt_status);
bool is_equal(std::vector<double> current_compass, int current_traffic_sign);

void car_run();
void car_pause();
void car_stop();


#endif // DRIVING_CONTROLLER_H_INCLUDED
