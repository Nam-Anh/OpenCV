#include "fuzzy.h"

int normalize_steering_angle(double steer_angle) {
    if (steer_angle > 90) {
        steer_angle = 90;
    } else if (steer_angle < -90) {
        steer_angle = -90;
    }
    steer_angle = (int) steer_angle / 10 * 10;

//    if(steer_angle > 50){
//        return 90;
//    }
//
//    if(steer_angle > 30){
//        return 50;
//    }
//
//    if(steer_angle > 20){
//        return 30;
//    }

    return steer_angle;
}


double get_speed_interval(double steer_angle, int throttle_value, int max_throttle, bool has_object) {
    if (steer_angle > 90) {
        steer_angle = 90;
    } else if (steer_angle < -90) {
        steer_angle = -90;
    }
    if (throttle_value >= max_throttle) {
        if (has_object){
            return 30;
        }
        if (std::abs(steer_angle) >= 80) {
            return 30;
        }
//
        if (std::abs(steer_angle) >= 60) {
            return 30;
        }

        if (std::abs(steer_angle) > 40) {
            return 30;
        }

        if (std::abs(steer_angle) > 30) {
            return 30;
        }

        if (std::abs(steer_angle) >= 10) {
            return throttle_value;
        }

    }
    return throttle_value;
}

double get_speed(double pre_angle, double current_angle, int current_speed, int max_speed, int curve_speed){
    int difference_angle = std::abs(current_angle - pre_angle);
    if (difference_angle > 60){
        return 20;
    }

    if (std::abs(current_angle) >= 20 && std::abs(current_angle) < 90){
        return max_speed - std::abs(current_angle - pre_angle) * 0.2;
    }
    return curve_speed;
}

double get_speed_using_flip(float flip, int max_speed){
    if (std::abs(flip) > 15){
        return 20;
    }
    if (std::abs(flip) > 10){
        return 30;
    }

    if (std::abs(flip) > 5){
        return 30;
    }
    return max_speed;
}

double calcualte_throttle(double params[], int p_size, double steer_angle){
    double result = 0;
    for(int i=0;i<p_size;i++){
        result += params[i]*std::pow(steer_angle, i);
    }

    return result;
}

double get_speed_formula(double steer_angle, int throttle_value, int max_throttle) {
    if(throttle_value < max_throttle)
        return throttle_value;

    switch (max_throttle){
    case 60:
        double params[] = {5.588*10, -1.640*std::pow(10,-3), -5.792*std::pow(10,-3),4.570*std::pow(10,-7), 3.440*std::pow(10,-7)};
        int param_length = 5;
        return calcualte_throttle(params, param_length, steer_angle);
    }

}
