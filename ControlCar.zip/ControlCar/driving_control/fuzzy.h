#ifndef FUZZY_H_INCLUDED
#define FUZZY_H_INCLUDED

#include <iostream>
#include <cmath>


using namespace std;

int normalize_steering_angle(double steer_angle);
double get_speed_interval(double steer_angle, int throttle_value, int max_throttle, bool has_object);
double get_speed(double pre_angle, double current_angle, int current_speed, int max_speed, int curve_speed);
double get_speed_formula(double steer_angle, int throttle_value, int max_throttle);
double get_speed_using_flip(float flip, int max_speed);
#endif // FUZZY_H_INCLUDED
