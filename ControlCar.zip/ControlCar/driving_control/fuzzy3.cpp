#include "fuzzy.h"

int normalize_steering_angle(double steer_angle) {
    if (steer_angle > 90) {
        steer_angle = 90;
    } else if (steer_angle < -90) {
        steer_angle = -90;
    }
    steer_angle = (int) steer_angle / 10 * 10;

    if(steer_angle > 50){
        return 90;
    }

    if(steer_angle > 30){
        return 50;
    }

    if(steer_angle > 20){
        return 30;
    }

    return steer_angle;
}


double get_speed_interval(double steer_angle, int throttle_value, int max_throttle) {
    if (steer_angle > 90) {
        steer_angle = 90;
    } else if (steer_angle < -90) {
        steer_angle = -90;
    }
    if (throttle_value >= max_throttle) {
        if (std::abs(steer_angle) >= 80) {
            return 20;
        }

        if (std::abs(steer_angle) >= 50) {
            return 20;
        }

        if (std::abs(steer_angle) > 40) {
            return 21;
        }

        if (std::abs(steer_angle) > 30) {
            return 23;
        }

        if (std::abs(steer_angle) >= 10) {
            return 25;
        }

    }
    return throttle_value;
}

double calcualte_throttle(double params[], int p_size, double steer_angle){
    double result = 0 ;
    for(int i=0;i<p_size;i++){
        result += params[i]*std::pow(steer_angle, i);
    }

    return result;
}

double get_speed_formula(double steer_angle, int throttle_value, int max_throttle) {
    if(throttle_value < max_throttle)
        return throttle_value;

    switch (max_throttle){
    case 50:
        double params[] = {5.588*10, -1.640*std::pow(10,-3), -5.792*std::pow(10,-3),4.570*std::pow(10,-7), 3.440*std::pow(10,-7)};
        int param_length = 5;
        return calcualte_throttle(params, param_length, steer_angle);
    }

}
