#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <fstream>
using namespace std;
using namespace cv;

/*Global variables*/
int const WIDTH_resize = 160;
int const HEIGHT_resize = 120;
Point preCenter;
double steering_angle;
double halfRoadWidth;
/*----------------*/

/*Supported functions*/
std::string base_name(std::string const & path) {
    return path.substr(path.find_last_of("/\\") + 1);
}
Mat test(Mat src);
Mat ROI(Mat src, int vect[]);
Mat smoothImage(Mat src);
Mat grayScale(Mat src);
Mat smoothImage(Mat src);
Mat contoursMat(Mat src);
double getSlope(Vec4f l);
vector<vector<Point> > contoursGet(Mat src);
Vec4f lineGet(vector<Point> contour);
vector<Point> contourFilter(vector<vector<Point> > contours);
int laneSlope(Mat src);
double lane_get_contour_visual(Mat src);

double getTheta(Point car, Point dst);
/*-------------------*/
int main(int argc, char* argv[]) {
    VideoCapture cap(argv[1]);
    if (!cap.isOpened()) {
        cerr << "Unable to open video!" << endl;
        return -1;
    }
    int count = 0;
    Mat frame;
    char key = -1;
    namedWindow("Input video", 1);

    while (key != 27) {
        cap >> frame;
        count++;
        if (count >= 1300) {
            imshow("src", frame);
            Mat I = test(frame);
            imshow("Input video", I);

            key = waitKey(15);
            if (key == 'p') {
                imwrite("../PointerScanImage/savedImage.jpg", frame);
                waitKey(0);
            }
        }
    }

    return 0;
}

Mat test(Mat src) {
    Mat dst;
    //Start Processing
    resize(src, src, Size(160, 120));
    //First ROI to cut off Fucking objects
    Point offset = Point(0, 50);
    int vect[] = {offset.x, offset.y, WIDTH_resize - 2 * offset.x, HEIGHT_resize - offset.y};
    //Process with the whole frame
    dst = ROI(src, vect);
//    dst = src.clone();
    dst = grayScale(dst);
    dst = contoursMat(dst);
    steering_angle = lane_get_contour_visual(dst);

    return dst;
}

Mat grayScale(Mat src) {
    Mat dst;
    cvtColor(src, dst, COLOR_BGR2GRAY);
    threshold(dst, dst, 240, 255, THRESH_BINARY);
    return dst;
}

Mat ROI(Mat src, int vect[]) {
    Mat roi;
    roi = src(Rect(vect[0], vect[1], vect[2], vect[3]));
    return roi;
}

Mat smoothImage(Mat src) {
    Mat dst = Mat::zeros(src.size(), CV_8UC1);
    dst = src.clone();
    //Smooth image for detecting center
    int count_black = 0;
    int count_white = 0;
    int offset = 4;
    int black_threshold = (int) (offset * offset * 4) * 60 / 100;
    int white_threshold = (int) (offset * offset * 4) * 60 / 100;

    for (int y = offset; y < src.rows - offset; y++) {
        for (int x = offset; x < src.cols - offset; x++) {
            if (dst.at<uchar>(y, x) == 255) {
                count_black = 0;
                for (int a = y - offset; a < y + offset; a++) {
                    for (int b = x - offset; b < x + offset; b++) {
                        if (dst.at<uchar>(a, b) == 0) {
                            count_black++;
                        }
                    }
                }
                if (count_black > black_threshold)
                    dst.at<uchar>(y, x) = 0;
            } else {
                count_white = 0;
                for (int a = y - offset; a < y + offset; a++) {
                    for (int b = x - offset; b < x + offset; b++) {
                        if (src.at<uchar>(a, b) == 255) {
                            count_white++;
                        }
                    }
                }
                if (count_white > white_threshold)
                    dst.at<uchar>(y, x) = 255;
            }
        }
    }

    return dst;
}

Mat contoursMat(Mat src) {
    Mat dst;
    vector<vector<Point> > contours;
    vector<vector<Point> > newContours(contours.size());
    vector<Vec4i> hierarchy;

    findContours(src, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));


    vector<Point> approxShape;
    dst = Mat::zeros(src.size(), CV_8UC1);
    for (size_t i = 0; i < contours.size(); i++) {
        Scalar color = Scalar(255, 255, 255);
        drawContours(dst, contours, i, 255, CV_FILLED); // fill white

    }

    return dst;
}

vector<vector<Point> > contoursGet(Mat src) {

    Mat dst;
    vector<vector<Point> > contours;
    vector<vector<Point> > newContours;
    vector<Vec4i> hierarchy;

    findContours(src, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0));
    for (size_t i = 0; i < contours.size(); i++) {
        if (contourArea(contours.at(i)) > 120) {
            newContours.push_back(contours.at(i));
        }
    }
    return newContours;
}

vector<Point> contourFilter(vector<vector<Point> > contours) {
    vector<Point> newContour;
    for (size_t i = 0; i < contours.size(); i++) {
        vector<Point> cnt = contours.at(i);
        for (int j = 0; j < cnt.size(); j++) {
            Point pt = cnt.at(j);
            newContour.push_back(pt);
        }

    }
    return newContour;
}

int laneSlope(Mat src) {
    Mat dst = Mat::zeros(src.size(), CV_8UC1);
    cvtColor(src, dst, COLOR_BGR2GRAY);
    /*Detect on two halves of frame */
    Mat firstHalf, secondHalf;
    //ROI
    //Second ROI to divide the frame into 2 parts
    //First Half
    Point offsetF = Point(0, 0);
    int vectFirst[] = {offsetF.x, offsetF.y, src.cols / 2, src.rows};
    firstHalf = ROI(dst, vectFirst);

    //Second Half
    Point offsetS = Point(firstHalf.cols, 0);
    int vectSecond[] = {offsetS.x, offsetS.y, src.cols - firstHalf.cols, src.rows};
    secondHalf = ROI(dst, vectSecond);

    /*Contour processing*/
    /*Variable for contour processing*/
    vector<vector<Point> > firstContours, secondContours;
    vector<Point> firstGroup, secondGroup;
    Vec4f f, s;
    int alphaF, alphaS;
    alphaF = 0;
    alphaS = 0;
    /*-------------------------------*/

    /*Contours Processing*/
    firstContours = contoursGet(firstHalf);
    secondContours = contoursGet(secondHalf);
    /*-------------------------------*/

    /*Contours group*/
    if (firstContours.size() != 0) {
        firstGroup = contourFilter(firstContours);
    }
    if (secondContours.size() != 0) {
        secondGroup = contourFilter(secondContours);
    }
    /*-------------------------------*/

    /*Fit Line*/
    if (firstGroup.size() != 0) {
        f = lineGet(firstGroup);
        alphaF = (int) getSlope(f);
    }
    if (secondGroup.size() != 0) {
        s = lineGet(secondGroup);
        s[2] = s[2] + firstHalf.cols;
        s[3] = s[3];
        alphaS = (int) getSlope(s);
    }
    /*-------------------------------*/

    if (alphaF >= 0 && alphaS >= 0) {
        return 1;
    } else if (alphaF <= 0 && alphaS <= 0) {
        return -1;
    } else if ((alphaF <= 0 && alphaS >= 0) || (alphaF >= 0 && alphaS <= 0)) {
        return 2;
    } else {
        return 0;
    }
    return 0;
}

Vec4f lineGet(vector<Point> contour) {
    Vec4f l;
    fitLine(contour, l, CV_DIST_L2, 0, 0.01, 0.01);
    return l;
}

double getSlope(Vec4f l) {
    double a, b;
    double pi = 3.1415926;
    a = l[0];
    b = l[1];
    double slope = atan(b / a);
    slope = slope * 180 / pi;
    return -slope;

}

double getTheta(Point car, Point dst) {
    if (dst.x == car.x) return 0;
    if (dst.y == car.y) return (dst.x < car.x ? -90 : 90);
    double pi = acos(-1.0);
    double dx = dst.x - car.x;
    double dy = car.y - dst.y; // image coordinates system: car.y > dst.y
    if (dx < 0) return atan(-dx / dy) * 180 / pi;
    return -atan(dx / dy) * 180 / pi;
}

double lane_get_contour_visual(Mat src) {

//    resize(src, src, Size(160, 120));
//    Point offset = Point(0, 120 / 3);
//    int vect[] = {offset.x, offset.y, 160, 120 - offset.y};
//    //Process with the whole frame
//    src = ROI(src, vect);
//    src = smoothImage(src);
    //cout<<endl<<src.channels()<<endl;
    Mat dst;
    dst = Mat::zeros(src.rows, src.cols, CV_8UC3);
    for (int y = 0; y < src.rows; y++)
        for (int x = 0; x < src.cols; x++) {
            if (src.at<uchar>(y, x) == 255) {
                dst.at<Vec3b>(y, x)[0] = 255;
                dst.at<Vec3b>(y, x)[1] = 255;
                dst.at<Vec3b>(y, x)[2] = 255;
            }

        }

    int y = dst.rows * 2 / 5;
    int leftStart, rightStart;
    leftStart = -1;
    rightStart = -1;

    Point left_start = Point(-1, -1);
    Point left_end = Point(-1, -1);
    Point right_start = Point(-1, -1);
    Point right_end = Point(-1, -1);
    Point center = Point(-1, -1);


    bool met = false;
    int count_black = 0;

    for (int x = 0; x < src.cols; x++) {
        if (src.at<uchar>(y, x) == 255 && !met) {
            left_start.x = x;
            left_start.y = y;
            met = true;
        } else if (src.at<uchar>(y, x) == 0 && met) {
            count_black++;
            if (count_black >= 10) {
                left_end.x = x - 10;
                left_end.y = y;
                met = false;
                break;
            }
        } else if (src.at<uchar>(y, x) == 255 && met) {
            count_black = 0;
        }
    }

    circle(dst, left_start, 3, Scalar(255, 0, 0), 3, LINE_8);
    circle(dst, left_end, 3, Scalar(0, 255, 0), 3, LINE_8);


    for (int x = left_end.x + 60; x < src.cols; x++) {
        if (src.at<uchar>(y, x) == 255) {
            right_start.x = x;
            right_start.y = y;
            break;
        }
    }

    circle(dst, right_start, 3, Scalar(0, 255, 0), 3, LINE_8);

    if (left_end.x != -1 && right_start.x != -1) {
        center.x = (int) (left_end.x + right_start.x) / 2;
        center.y = y;
        preCenter = center;
        halfRoadWidth = center.x - left_end.x;
    } else if (right_start.x == -1 && left_end.x != -1) {
        //Case when there is LEFT but not RIGHT
        int direction = laneSlope(dst);
        if (direction == 1) {
            /*Case when the road directs to the right
             And there is only left lane*/
            center.x = left_end.x + halfRoadWidth;
            center.y = y;
            preCenter = center;
        } else if (direction == -1) {
            /*Case when the road directs to the left
             And there is only right lane*/
            center.x = left_end.x - halfRoadWidth;
            center.y = y;
            preCenter = center;
        } else {
            /*Case when there is both lanes, but one of them is too short
             And the left or right lane can not be detected.
             However slopes of these lanes are still != 0 */
            center = preCenter;
        }
    } else {
        /*Not left and not right*/
        center = preCenter;
    }
    circle(dst, center, 3, Scalar(0, 0, 255), 3, LINE_8);
    steering_angle = getTheta(center, Point(src.cols / 2, 120));
    imshow("DST", dst);

    return steering_angle;
}
