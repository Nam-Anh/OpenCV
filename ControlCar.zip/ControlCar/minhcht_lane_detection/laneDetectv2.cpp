#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <fstream>
#include <set>
#include <algorithm>
#include <stdlib.h>
#include <bits/c++config.h>
#include "laneDetectv2.h"
using namespace std;
using namespace cv;



bool DODGED = false;
int SLIDETHICKNESS = 3;
int CONTROL = 15;
int PCONTROL = 50;
int LRCONTROL = 80;
int midX=80;
int POS_AGLE = 30;
int width = 50;
float preAngle = 0;
Point preP = Point(80,POS_AGLE);
int FILTERCONTROL = 200;//180
int HLSCONTROL = 130;
int LENGTHCONTROL = 5;
int OBJCONTROL = 5;
int DODGECONTROL = 10;
int DODGESEQUENCE = 0;
int DODGEDIR = -1;
int GREENCONTROL = 50;
bool switched = false;

std::vector<std::vector<Point> > findCenter(std::vector<Mat> input);
Mat MROI(Mat src, int vect[]);
std::vector<Mat> seraprateLayer(Mat input);
std::vector<std::vector<Point> > rejectOutliner(std::vector<std::vector<Point> > input);
Point pointCal(Rect obj,bool hasCross,int dir,bool usingCenter,int method,std::vector<std::vector<Point> > input);
float angleByAtan2(Point first,Point second);
Mat drawPoint(bool hasCross,int dirDodge,Rect objRect,float anlge,Point center,std::vector<std::vector<Point> > input,Mat raw);
float angleValCalVisual(bool& hasObject,Rect objRect,bool usingCenter,int method,Mat input,Mat &checkMat);
float angleValCal(bool usingCenter,int method,Mat input);
Mat drawLane(Mat input);
int objPos(Rect objRect,std::vector<std::vector<Point> > input);
Mat preProcessPipeLine(Mat input,int method);
Mat grayScale(Mat src);
Mat blurI(Mat src);
Mat contoursMat(Mat src,int method);
Mat greenI(Mat src) ;
Mat roadDetect(Mat input);
Mat drawGreenLane(Mat input);
Mat birdViewTranform(Mat source);
/////////////////////////////////////////////////////////////////////////
Mat roadDetect(Mat input) {
    Mat res;
//    GaussianBlur(input,input,Size(23,23),0,0);
//    bilateralFilter(input,res,5,20,20,BORDER_DEFAULT);

    medianBlur(input,res,5);

    adaptiveThreshold(res,res,255,ADAPTIVE_THRESH_GAUSSIAN_C,CV_THRESH_BINARY_INV,19,6);
//    morphologyEx(res,res,CV_MOP_OPEN,13);
    return res;
}
///////////////////////NAM ANH - COLOR NORMALIZE//////////////////////////
Mat preProcessPipeLine(Mat input,int method) {
    Mat res;

    res = greenI(input);
    res = grayScale(res);
    res = contoursMat(res,method);
    res = blurI(res);


    return res;
}
Mat drawGreenLane(Mat input) {
    Mat res;
    Mat dst;
    Canny(input,res,100,300,3,false);
    int dilation_size = 2;

    Mat element = getStructuringElement( 0,
                                         Size( 2*dilation_size + 1, 2*dilation_size+1 ),
                                         Point( dilation_size, dilation_size ) );
    dilate( res, dst, element );
    return dst;
}
Mat drawLane(Mat input) {
    Mat res;
    int dilation_size = 1;
    Mat element = getStructuringElement( 0,
                                         Size( 2*dilation_size + 1, 2*dilation_size+1 ),
                                         Point( dilation_size, dilation_size ) );
    dilate( input, res, element );
    return res;
}
Mat grayScale(Mat src) {
    Mat dst;
    cvtColor(src, dst, COLOR_BGR2GRAY);
    threshold(dst, dst, 200, 255, THRESH_BINARY_INV);
    return dst;
}
Mat blurI(Mat src) {
    int kernel_size = 3;
    Mat src_clone, dst;

    src_clone = src.clone();
    blur(src_clone, dst, Size(kernel_size,kernel_size));

    return dst;
}
Mat contoursMat(Mat src,int method) {
    Mat src_gray, dst;
    vector<vector<Point> > contours;
    vector<vector<Point> > newContours(contours.size());
    vector<Vec4i> hierarchy;
    if(src.channels() == 3) {
        cvtColor(src, src_gray, COLOR_BGR2GRAY);
    } else {
        src_gray = src.clone();
    }

    findContours(src_gray, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE, Point(0, 0));

    dst = Mat::zeros(src.size(), CV_8UC1);
    int min = 1000;
    int max = -1000;
    int posMin = -1;
    int posMax = -1;
    for (int i = 0; i < contours.size(); i++) {
        if(contourArea(contours[i]) > 100) {
            Moments M1 = moments(contours[i],false);
            int center = (M1.m10/M1.m00);
            if (method < 0){
                drawContours(dst, contours, i, 255, CV_FILLED);
            }
            if (min > abs(center)){
                min = center;
                posMin = i;
            }
            if (max < abs(center)){
                max = center;
                posMax = i;
            }
        }
    }
    if (method == 1){
            drawContours(dst, contours, posMin, 255, CV_FILLED);
    }
    if (method == 0){
        drawContours(dst, contours, posMax, 255, CV_FILLED);
    }
     // fill white
    return dst;
}

Mat greenI(Mat src) {
    int rangeH, rangeS, rangeV;
    /*============DEFINE RANGE FOR HUE COLOR==============*/
    int max_hue = 179;
    int min_hue = 0;
    /*Lower thresh*/
    int l_green;
    /*Upper thresh*/
    int h_green;
    /*====================================================*/
    /*Specific range*/
    l_green = 35;
    h_green = 90;

    Mat dst;
    cvtColor(src, dst, CV_BGR2HSV);
    for (int y = 0; y < dst.rows; ++y) {
        for (int x = 0; x < dst.cols; ++x) {
            /*===================HUE PROCESSING==========================*/
            if (dst.at<Vec3b>(y, x)[0] <= l_green || dst.at<Vec3b>(y, x)[0] > h_green) {
                /*===========================GREEN================================*/
                rangeH = 0;
                dst.at<Vec3b>(y, x)[0] = rangeH;
                /*===================SATURATION + VALUE PROCESSING================*/
                rangeS = 0;
                rangeV = 255;

                dst.at<Vec3b>(y, x)[1] = rangeS;
                dst.at<Vec3b>(y, x)[2] = rangeV;
                /*=================================================================*/
            } else {
                rangeH = 57;
                dst.at<Vec3b>(y, x)[0] = rangeH;
                /*===================SATURATION + VALUE PROCESSING================*/
                int threshG = GREENCONTROL;
                if (dst.at<Vec3b>(y, x)[1] < threshG && dst.at<Vec3b>(y, x)[2] >= threshG) {
                    //White case
                    rangeS = 0;
                    rangeV = 255;
                } else if (dst.at<Vec3b>(y, x)[1] >= threshG && dst.at<Vec3b>(y, x)[2] >= threshG) {
                    //Light Color case
                    rangeS = 255;
                    rangeV = 255;
                } else if (dst.at<Vec3b>(y, x)[1] >= threshG && dst.at<Vec3b>(y, x)[2] < threshG) {
                    //Dark Color case
                    rangeS = 255;
                    rangeV = 255;
                } else {
                    //Black case
                    rangeS = 0;
                    rangeV = 255;
                }

                dst.at<Vec3b>(y, x)[1] = rangeS;
                dst.at<Vec3b>(y, x)[2] = rangeV;
                /*==========================================*/
            }
        }
    }
    cvtColor(dst, dst, CV_HSV2BGR);
    return dst;
}
/////////////////////NAM ANH CODE-END///////////////////////

Mat MROI(Mat src, int vect[]) {
    Mat roi;
    roi = src(Rect(vect[0], vect[1], vect[2], vect[3]));
    return roi;
}

std::vector<std::vector<Point> > findCenter(std::vector<Mat> input) {
    std::vector<std::vector<Point> > res;
    int inputN = input.size();

    for (int i =0 ; i < inputN; i++) {
        std::vector<std::vector<Point> > cnts;
        std::vector<Point> tmp;
        findContours(input[i],cnts,CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));
        int cntsN = cnts.size();
        if (cntsN == 0) {
            res.push_back(tmp);
            continue;
        }


        for (int j = 0; j < cntsN; j++) {
            int area = contourArea(cnts[j],false);
            if (area > 3) {
                Moments M1 = moments(cnts[j],false);
                Point2f center1 = Point2f( static_cast<float>(M1.m10/M1.m00) , static_cast<float>(M1.m01/M1.m00) );
                center1.y = center1.y + SLIDETHICKNESS*i;
                if (center1.x >0 && center1.y >0) {
                    tmp.push_back(center1);
                }
            }
        }
        res.push_back(tmp);
    }

    return res;
}

std::vector<Mat> seraprateLayer(Mat input) {
    int rowN = input.rows;
    std::vector<Mat> res;
    for (int i = 0; i <= rowN-SLIDETHICKNESS; i+=SLIDETHICKNESS) {
        Mat tmp;
        int vect[] = {0,i,160,SLIDETHICKNESS};
        tmp = MROI(input,vect);
        res.push_back(tmp);
    }
    return res;
}
std::vector<std::vector<Point> > rejectOutliner(std::vector<std::vector<Point> > input) {
    std::vector<Point>  left;
    std::vector<Point>  right;
    std::vector<std::vector<Point> > res;
    int inputN = input.size();
    int preL=-1;
    int preR=-1;
    if (inputN == 0) {
        return input;
    }
    for (int i =inputN-1; i>=inputN/3; i--) {
        std::vector<Point> curr = input[i];
        int currN = curr.size();
        if (currN ==0) {
            continue;
        }
        int pos = -1;
        int min = 1000;
        for (int j=currN-1; j >= 0; j--) {
            if (curr[j].x < midX && abs(curr[j].x-midX) < min) {
                min = abs(curr[j].x-midX);
                pos = j;

            }
        }
        if (pos>=0) {
            preL = curr[pos].x;
            left.push_back(curr[pos]);
            break;
        }
    }

    for (int i =inputN-1; i>=inputN/3; i--) {
        std::vector<Point> curr = input[i];
        int currN = curr.size();
        if (currN ==0) {
            continue;
        }
        int pos = -1;
        int min = 1000;
        for (int j=0; j < currN; j++) {
            if (curr[j].x > midX && abs(curr[j].x-midX) < min) {
                min = abs(curr[j].x-midX);
                pos = j;

            }
        }
        if (pos >=0) {
            right.push_back(curr[pos]);
            preR = curr[pos].x;
            break;
        }
    }

    if (abs(preR-preL) < LRCONTROL && preL > 0 && preR > 0) {
        if (left[0].y>right[0].y) {
            right.pop_back();
            preR = -1;
        } else {
            left.pop_back();
            preL = -1;
        }
    }



    if (left.size()>0) {
        preL = left[0].x;
    }
    if (right.size()>0) {
        preR = right[0].x;
    }
    int preLCache = preL;
    int preRCache = preR;

    if (preL >0)
        for (int i =inputN-1; i>=0; i--) {
            std::vector<Point> curr = input[i];
            int currN = curr.size();
            if (currN ==0) {
                continue;
            }
            int minL = 1000;
            int posL = -1;
            for (int j=0; j < currN; j++) {
                if (CONTROL > abs(curr[j].x-preL) && minL > abs(curr[j].x-160)) {
                    minL = abs(curr[j].x-midX);
                    posL = j;
                }

            }
            if (posL >= 0) {
                left.push_back(curr[posL]);
                preL = curr[posL].x;
            }

        }

    if (preR >0)
        for (int i=inputN-1; i>=0; i--) {
            std::vector<Point> curr = input[i];
            int currN = curr.size();
            if (currN ==0) {
                continue;
            }
            int minR = 1000;
            int posR = -1;
            for (int j=0; j < currN; j++) {
                if (CONTROL > abs(curr[j].x-preR) && minR > abs(curr[j].x)) {
                    minR = abs(curr[j].x-midX);
                    posR = j;
                }

            }
            if (posR >= 0) {
                right.push_back(curr[posR]);
                preR = curr[posR].x;
            }
        }
    std::vector<Point> emptyVec;
    if (left.size() > LENGTHCONTROL) {
        res.push_back(left);
    } else {
        preLCache = -1;
        res.push_back(emptyVec);
    }

    if (right.size() > LENGTHCONTROL) {
        res.push_back(right);
    } else {
        preRCache = -1;
        res.push_back(emptyVec);
    }
    if (preRCache>0 && preLCache<0 ) {
        if (abs(preRCache/2-midX) < PCONTROL) {
            midX = preRCache/2;
        }

    }
    // (160 - prel)*1/3 + prel = 160/3 + prel*2/3
    if (preLCache>0 && preRCache<0 ) {
        if (abs(abs(preLCache-160)/2+preLCache-midX) < PCONTROL) {
            midX = abs(preLCache-160)/2+preLCache;
        }
    }

    if (preRCache>0 && preLCache>0) {
        if (abs(midX-(preLCache+preRCache)/2) < PCONTROL) {
            midX = (preLCache+preRCache)/2;
        }

    }
    if (midX > 140) {
        midX = 140;
    }
    if (midX < 20) {
        midX = 20;
    }
    return res;
}
Point pointCal(Rect obj,bool hasCross,int dir,bool usingCenter,int method,std::vector<std::vector<Point> > input) {
    Point res;
    res.x=-1;
    res.y=-1;

    if (input.size()==0) {
        return preP;
    }
//    if (input[method].size()==0 && input[1-method].size()>0){
//        method = 1- method;
//        switched = true;
//    }
    std::vector<Point> chosen = input[method];
    std::vector<Point> checker = input[1-method];
    int chosenN = chosen.size();
    int checkN  = checker.size();

//    if (chosenN==0 && checkN==0) {
//        return preP;
//        if (checkN == 0) {
//            if (method==1) {
//                res = Point(50,POS_AGLE);
//            } else {
//                res = Point(110,POS_AGLE);
//            }
//            preP = res;
//
//            return preP;
//        }
//
//    }

    int pos = -1;
    int posCheck = -1;
    int tmpPos = -1;
    if (chosenN != 0)
        for (int i=0; i<chosenN; i++) {
            tmpPos = i;
            if (chosen[i].y<=POS_AGLE) {
                pos = i;
                break;
            }
        }
    if (pos < 0) {
        pos = tmpPos;
    }
    tmpPos = -1;
    if (checkN != 0)
        for (int i=0; i<checkN; i++) {
            tmpPos = i;
            if (checker[i].y<=POS_AGLE) {
                posCheck = i;
                break;
            }
        }
    if (posCheck <0) {
        posCheck = tmpPos;
    }

    if (posCheck>=0 && !hasCross) {
        if (checker[posCheck].y >= 32) {
            posCheck = -1;
        }
    }
    if (pos >= 0 && !hasCross) {
        if (chosen[pos].y >= 32) {
            pos = -1;
        }
    }
    if (posCheck>=0 && pos >= 0) {
        width = abs(chosen[pos].x-checker[posCheck].x)/2;
        if (width>40) {
            width = 40;
        }
        if (width<10) {
            width = 10;
        }
        if (abs(chosen[pos].y-POS_AGLE) > abs(checker[posCheck].y-POS_AGLE) && !hasCross) {
            pos = -1;
        }
    }
    int theWey;
    if (method==0) {
        theWey = 1;
    } else {
        theWey = -1;
    }
//    if (pos >0 && posCheck >0 && !hasCross){
//        if (abs(chosen[pos].x-checker[posCheck].x) >= 20){
//            pos = -1;
//        }
//    }

    if (pos >= 0) {
        res.x = chosen[pos].x + (width)*(theWey);
        res.y = chosen[pos].y;
//        if (hasCross){
//            res.x -= width*(theWey)/3;
//        }
    } else {
        if (hasCross) {
            if (method == 1) {
                preP = Point(120,POS_AGLE);
                return preP;
            } else {
                preP = Point(40,POS_AGLE);
                return preP;
            }
        }
        if (posCheck >= 0) {
            res.x = checker[posCheck].x - width*(theWey);
            res.y = checker[posCheck].y;
        } else {

            res = preP;
            return res;
            if (width >= 30) {
                return res;
            }

            if (method == 0) {
                preP = Point(100,POS_AGLE);
                return preP;
            } else {
                preP = Point(60,POS_AGLE);
                return preP;
            }
        }
    }



//    if (sqrt(pow(res.x-preP.x,2) + pow(res.y-preP.y,2)) > PCONTROL && preP.x >0){
//        return preP;
//    }

    if (dir >=0) {
        res.y = POS_AGLE;
        bool dodged = false;
        if (dir == 0) {
            if (res.x < obj.x+obj.width+30) {
                res.x = obj.x+obj.width+30;
                dodged = true;
            }


        } else {
            if (res.x > obj.x-30) {
                res.x = obj.x-30;
                dodged = true;
            }

        }
        DODGED = dodged;
        if (dodged) {
            Point objCenter;
            objCenter.x = obj.x+obj.width/2;
            objCenter.y = obj.y+obj.height/2;
            if (pos == 0) {
                midX = (objCenter.x + 160)/2;
            }
            if (pos == 1) {
                midX = objCenter.x/2;
            }

        }
        preP = res;
        return res;
    }
//    res.y = POS_AGLE;
    preP = res;
    return res;
}
float angleByAtan2(Point first,Point second) {
    int x =(first.x-second.x);
    int y =(first.y-second.y);
    float res = atan2(y,x);
    res = res/CV_PI*90;
    res = 45 - res;
    return res;
}
float angleCal(Point hoverPoint) {
    return angleByAtan2(Point(80,80),hoverPoint);
}
int objPos(Rect objRect,std::vector<std::vector<Point> > input) {
    int inputN = input.size();
    if (inputN == 0) {
        return -1;
    }
    Point objCenter;
    objCenter.x = objRect.x+objRect.width/2;
    objCenter.y = objRect.y+objRect.height/2;
//    if (objCenter.y < 0){
//        return -1;
//    }
    int min = 50;
    int pos = -1;
    int countAvai = 0;
    for (int i=0; i < 2; i++) {
        std::vector<Point> curr = input[i];
        int currN = curr.size();
        if (currN==0) {
            continue;
        }
        countAvai += 1;
        for (int j =0; j < currN; j++) {
            if (abs(objCenter.x-curr[j].x) < min) {
                min = sqrt(pow(curr[j].x-objCenter.x,2) + pow(curr[j].y-objCenter.y,2));
                pos = i;
            }
        }
    }

    return pos;
}
bool isCross(Mat input) {
    std::vector<std::vector<Point> > cnts;
    findContours(input,cnts,CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));
    int cntsN = cnts.size();
    if (cntsN == 0) {
        return false;
    }
    std::vector<Point> cnt;
    int max = - 1;
    for (int i=0; i < cntsN; i++) {
        int area = contourArea(cnts[i],false);
        if (max < area) {
            max = area;
            cnt = cnts[i];
        }
    }
    Point exLeft;
    Point exRight;
    Point exTop;
    Point exBott;
    exLeft.x = 1000;
    exRight.x = -1000;
    exBott.y = -1000;
    exTop.y = 1000;

    for (size_t j=0; j < cnt.size(); j++) {
        Point current = cnt[j];
        if (current.x < exLeft.x) {
            exLeft = current;
        }
        if (current.x > exRight.x) {
            exRight = current;
        }
        if (current.y > exBott.y) {
            exBott = current;
        }
        if (current.y < exTop.y) {
            exTop = current;
        }
    }
    Moments M1 = moments(cnt,false);
    int center = M1.m10/M1.m00;
    if (exRight.x > exBott.x && exLeft.x < exBott.x
            && abs((exLeft.x+exRight.x)/2 - center) <=10
            && exLeft.y < exBott.y && exRight.y < exBott.y
            && abs(exLeft.x-exRight.x) >=20
            && abs(center-80) <= 10) {
//            cout << abs(exLeft.x-exRight.x) << "\n";
//        cout << abs(exLeft.x-exRight.x) << "\n";
        return true;
    }

    return false;
}
Mat drawPoint(bool hasCross,int dirDodge,Rect objRect,int method,float anlge,Point center,std::vector<std::vector<Point> > input,Mat raw) {
    int inputN = input.size();
    int radius = 1;
    if (inputN ==0) {
        return raw;
    }

//    Mat res = Mat::zeros(150,320,CV_8UC3);
    Mat res = raw.clone();
    cvtColor(res,res,CV_GRAY2BGR);
    for (int i =0; i < inputN; i++) {
        std::vector<Point> points = input[i];
        int pointsN = points.size();
        if (pointsN==0) {
            continue;
        }
        for (int j=0; j < pointsN; j++) {
//            circle(res,;
            if (i!=method) {
                circle(res, points[j], (int) radius,//Radius
                       Scalar(255,0,0),
                       (int) 2,//thick ness
                       LINE_AA);
            } else {
                circle(res, points[j], (int) radius,//Radius
                       Scalar(0,0,255),
                       (int) 2,//thick ness
                       LINE_AA);
            }


        }
    }
    circle(res, center, (int) 5,//Radius
           Scalar(255,0,255),
           (int) 2,//thick ness
           LINE_AA);
    Point org;
    org.y = res.rows/3;
    org.x = res.cols/3;
    stringstream covert;
    covert << int(anlge);

    string tmp = covert.str();


    putText(res, tmp, org, FONT_HERSHEY_SCRIPT_SIMPLEX, 1,
            Scalar(0,255,0), 2, 5);
    tmp = "";
    if (dirDodge == 0 && DODGED) {
        tmp = "->";
    }
    if (dirDodge == 1 && DODGED) {
        tmp = "<-";
    }
    org.y = res.rows/1.5;
    org.x = res.cols/2.7;
    putText(res, tmp, org, FONT_HERSHEY_SCRIPT_SIMPLEX, 1,
            Scalar(0,255,255), 2, 5);
    org.y = 65;
    org.x = midX;
    circle(res, org, (int) 5,//Radius
           Scalar(0,255,255),
           (int) 2,//thick ness
           LINE_AA);
    cv::rectangle(res, objRect, Scalar(255, 0, 255));
    org.y = res.rows/1.5;
    org.x = 0;
    if (hasCross) {
        putText(res, "  |||    |||", org, FONT_HERSHEY_SCRIPT_SIMPLEX, 1,
                Scalar(255,255,0), 2, 5);
    }

    return res;
}
std::vector<std::vector<Point> > mergePoints(std::vector<std::vector<Point> > firstInput,std::vector<std::vector<Point> > secondInput) {
    if (secondInput.size() ==0 ) {
        return firstInput;
    }
    if (firstInput.size()==0) {
        return secondInput;
    }

    int inputN = secondInput.size();
    for (int i=0 ; i < inputN; i++) {
        std::vector<Point> curr = secondInput[i];
        int currN = curr.size();
        if (currN == 0) {
            continue;
        }

        for (int j =0; j < currN; j++) {
            firstInput[i].push_back(curr[j]);
        }
    }
    return firstInput;
}
Mat birdViewTranform(Mat source) {
    double PI = 3.1415926;
    double focalLength, dist, alpha, beta, gamma;
    alpha =(5 -90) * PI/180;
    beta =(90 -90) * PI/180;
    gamma =(90 -90) * PI/180;
    focalLength = (double)500;
    dist = (double)115;
    Size image_size = source.size();
    double w = (double)image_size.width, h = (double)image_size.height;


    // Projecion matrix 2D -> 3D
    Mat A1 = (Mat_<float>(4, 3)<<
              1, 0, -w/2,
              0, 1, -h/2,
              0, 0, 0,
              0, 0, 1 );


    // Rotation matrices Rx, Ry, Rz

    Mat RX = (Mat_<float>(4, 4) <<
              1, 0, 0, 0,
              0, cos(alpha), -sin(alpha), 0,
              0, sin(alpha), cos(alpha), 0,
              0, 0, 0, 1 );

    Mat RY = (Mat_<float>(4, 4) <<
              cos(beta), 0, -sin(beta), 0,
              0, 1, 0, 0,
              sin(beta), 0, cos(beta), 0,
              0, 0, 0, 1	);

    Mat RZ = (Mat_<float>(4, 4) <<
              cos(gamma), -sin(gamma), 0, 0,
              sin(gamma), cos(gamma), 0, 0,
              0, 0, 1, 0,
              0, 0, 0, 1	);


    // R - rotation matrix
    Mat R = RX * RY * RZ;

    // T - translation matrix
    Mat T = (Mat_<float>(4, 4) <<
             1, 0, 0, 0,
             0, 1, 0, 0,
             0, 0, 1, dist,
             0, 0, 0, 1);

    // K - intrinsic matrix
    Mat K = (Mat_<float>(3, 4) <<
             focalLength, 0, w/2, 0,
             0, focalLength, h/2, 0,
             0, 0, 1, 0
            );


    Mat transformationMat = K * (T * (R * A1));
    Mat destination;
    warpPerspective(source, destination, transformationMat, image_size, INTER_CUBIC | WARP_INVERSE_MAP);
//    Mat empt;
//    empt = Mat::zeros(Size(destination.cols,destination.rows),CV_8UC1);
//    destination = newDrawLine(destination,empt);
    return destination;
}
float angleValCalVisual(bool &hasObject,Rect objRect,bool usingCenter,int method,Mat src,Mat &checkMat) {
    int vect[] = {0,45,160,75};
//    imshow("checksrc",src);
    if (src.cols == 0) {
        return preAngle;
    }
    objRect.y -= 45;
    resize(src,src,Size(160,120));
    Mat input = MROI(src,vect);
    int vectGreen[] = {0,0,160,75};
    Mat greenCross = MROI(src,vectGreen);
    greenCross = birdViewTranform(greenCross);
    greenCross = preProcessPipeLine(greenCross,-1);
    bool hasCross = isCross(greenCross);
    Mat greenLane = preProcessPipeLine(input,method);
    greenLane = drawGreenLane(greenLane);

    cvtColor(input,input,CV_RGB2GRAY);

//    input = roadDetect(input);
    threshold(input,input,FILTERCONTROL,255,THRESH_BINARY);
    input = drawLane(input);
    std::vector<std::vector<Point> > pairPointGreen;
    if (!hasCross) {

        std::vector<Mat> checkGreen = seraprateLayer(greenLane);
        pairPointGreen = findCenter(checkGreen);
    }


//    inRange(input,Scalar(0,HLSCONTROL,0),Scalar(255,255,255),input);
    std::vector<Mat> check = seraprateLayer(input);
    std::vector<std::vector<Point> > pairPoint = findCenter(check);

    if (!hasCross) {
        pairPoint = mergePoints(pairPoint,pairPointGreen);
    }


    std::vector<std::vector<Point> > filtedPoint = rejectOutliner(pairPoint);

    if (objRect.x >=0) {
        DODGEDIR = objPos(objRect,filtedPoint);
    } else {
        DODGEDIR = -1;
    }

    Point center = pointCal(objRect,hasCross,DODGEDIR,usingCenter,method,filtedPoint);
    if (DODGEDIR >= 0) {
        hasObject = true;
    } else {
        hasObject = false;
    }
    float res = angleCal(center);

    bitwise_or(input,greenLane,input);
    Mat checkImg = drawPoint(hasCross,DODGEDIR,objRect,method,res,center,filtedPoint,input);
//    imshow("gray",checkImg);
    checkMat = checkImg;
    preAngle = res;
    return res;
}
float angleValCal(bool usingCenter,int method,Mat input) {
    int vect[] = {0,45,160,75};
    Rect obj;
    resize(input,input,Size(160,120));
    input = MROI(input,vect);
    cvtColor(input,input,CV_RGB2GRAY);
    threshold(input,input,FILTERCONTROL,255,THRESH_BINARY);
    std::vector<Mat> check = seraprateLayer(input);
    std::vector<std::vector<Point> > pairPoint = findCenter(check);
    std::vector<std::vector<Point> > filtedPoint = rejectOutliner(pairPoint);
    Point center = pointCal(obj,false,1,usingCenter,method,filtedPoint);
    float res = angleCal(center);
    return res;
}
