/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   laneDetectv2.h
 * Author: minh
 *
 * Created on April 12, 2018, 11:04 PM
 */

#ifndef LANEDETECTV2_H
#define LANEDETECTV2_H
#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <fstream>
#include <set>
#include <algorithm>
#include <stdlib.h>
#include <bits/c++config.h>
using namespace std;
using namespace cv;

extern bool DODGED;
extern int FILTERCONTROL;
extern int LRCONTROL;
extern int SLIDETHICKNESS;
extern int CONTROL;
extern int PCONTROL;
extern int midX;
extern int POS_AGLE;
extern int width;
extern float preAngle;
extern Point preP;
extern int HLSCONTROL;
extern int LENGTHCONTROL;
extern int OBJCONTROL;
extern int DODGECONTROL;
extern int DODGESEQUENCE;
extern int DODGEDIR;
extern int GREENCONTROL;


std::vector<std::vector<Point> > findCenter(std::vector<Mat> input);
Mat MROI(Mat src, int vect[]);
std::vector<Mat> seraprateLayer(Mat input);
std::vector<std::vector<Point> > rejectOutliner(std::vector<std::vector<Point> > input);
Point pointCal(Rect obj,bool hasCross,int dir,bool usingCenter,int method,std::vector<std::vector<Point> > input);
float angleByAtan2(Point first,Point second);
Mat drawPoint(bool hasCross,int dirDodge,Rect objRect,float anlge,Point center,std::vector<std::vector<Point> > input,Mat raw);
float angleValCalVisual(bool& hasObject,Rect objRect,bool usingCenter,int method,Mat input,Mat &checkMat);
float angleValCal(bool usingCenter,int method,Mat input);
int objPos(Rect objRect,std::vector<std::vector<Point> > input);
Mat grayScale(Mat src);
Mat preProcessPipeLine(Mat input,int method);
Mat blurI(Mat src);
Mat contoursMat(Mat src,int method);
Mat greenI(Mat src) ;
Mat roadDetect(Mat input);
Mat drawGreenLane(Mat input);


#endif /* LANEDETECTV2_H */


