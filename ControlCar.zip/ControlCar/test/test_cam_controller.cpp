#include "camera_controller.h"



int main() {

    init_device();
    init_color_stream();
    init_depth_stream();


    while(true) {
        Mat frame = get_depth_frame();
        imshow("src", frame);

        //cout << cam.add()<<endl;

        char c = waitKey(30);
        if(c == 27) {
            break;
        }
    }

    return 0;
}

