#include "traffic_sign.h"

std::vector<TrafficSign> left_right_signs;
std::vector<TrafficSign> stop_sign;
std::vector<object_detector<image_scanner_type>> left_right_detectors;
std::vector<object_detector<image_scanner_type>> stop_detector;

image_window left_right_win;
image_window stop_win;

void load_SVM_detector() {
    left_right_signs.push_back(TrafficSign("turn left", "/home/ubuntu/model/svm_detectors/left.svm",
                                           rgb_pixel(255, 122, 0)));
    left_right_signs.push_back(TrafficSign("turn right", "/home/ubuntu/model/svm_detectors/right.svm",
                                           rgb_pixel(255, 255, 0)));
    stop_sign.push_back(TrafficSign("stop", "/home/ubuntu/model/svm_detectors/stop.svm",
                                    rgb_pixel(255, 0, 0)));
}

void init_detector() {
    for (int i = 0; i < left_right_signs.size(); i++) {
        object_detector<image_scanner_type> detector;
        deserialize(left_right_signs[i].svm_path) >> detector;
        left_right_detectors.push_back(detector);
    }
    object_detector<image_scanner_type> stop;
    deserialize(stop_sign[0].svm_path) >> stop;
    stop_detector.push_back(stop);
}

void init_traffic_sign_detection() {
    load_SVM_detector();
    init_detector();
}

int get_left_right_label(Mat frame, bool visual) {
    std::vector<rect_detection> rects;
    cv_image<bgr_pixel> image(frame);
    evaluate_detectors(left_right_detectors, image, rects);
    int label = -1;
    if (rects.size() > 0){
        label = rects[0].weight_index;
    }
    if (!visual){
        return label;
    }

    left_right_win.clear_overlay();
    left_right_win.set_image(image);

    for (unsigned long j = 0; j < rects.size(); ++j) {
        if (rects[j].detection_confidence > 0) {
            left_right_win.add_overlay(rects[j].rect, left_right_signs[rects[j].weight_index].color,
                            left_right_signs[rects[j].weight_index].name);
        }

    }
    return label;
}

std::vector<rect_detection> get_stop_sign(Mat frame, bool visual){
    std::vector<rect_detection> rects;
    cv_image<bgr_pixel> image(frame);
    evaluate_detectors(stop_detector, image, rects);
    if (!visual){
        return rects;
    }


    stop_win.clear_overlay();
    stop_win.set_image(image);

    for (unsigned long j = 0; j < rects.size(); ++j) {
        if (rects[j].detection_confidence > 0) {
            stop_win.add_overlay(rects[j].rect, stop_sign[rects[j].weight_index].color,
                            stop_sign[rects[j].weight_index].name);
        }
    }
    return rects;
}
