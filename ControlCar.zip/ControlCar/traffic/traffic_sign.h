/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   traffic_sign_detection.h
 * Author: atheros
 *
 * Created on April 17, 2018, 9:57 AM
 */

#ifndef TRAFFIC_SIGN_DETECTION_H
#define TRAFFIC_SIGN_DETECTION_H

#include <dlib/svm_threaded.h>
#include <dlib/gui_widgets.h>
#include <dlib/image_processing.h>
#include <dlib/data_io.h>
#include <dlib/image_transforms.h>
#include <opencv2/opencv.hpp>
#include <dlib/opencv/cv_image.h>
#include <dlib/opencv.h>
#include <iostream>

using namespace std;
using namespace dlib;
using namespace cv;

struct TrafficSign {
    std::string name;
    std::string svm_path;
    rgb_pixel color;

    TrafficSign(std::string name, std::string svm_path, rgb_pixel color) :
    name(name), svm_path(svm_path), color(color) {
    };
};

typedef scan_fhog_pyramid<pyramid_down<3> > image_scanner_type;


//declare variable here
extern std::vector<TrafficSign> left_right_signs;
extern std::vector<TrafficSign> stop_sign;
extern std::vector<object_detector<image_scanner_type>> left_right_detectors;
extern std::vector<object_detector<image_scanner_type>> stop_detector;
extern image_window left_right_win;
extern image_window stop_win;

void load_SVM_detector();
void init_detector();
void init_traffic_sign_detection();
int get_left_right_label(Mat frame, bool visual);
std::vector<rect_detection> get_stop_sign(Mat frame, bool visual);


#endif /* TRAFFIC_SIGN_DETECTION_H */

