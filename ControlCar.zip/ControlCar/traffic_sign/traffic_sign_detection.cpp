/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "traffic_sign_detection.h"
int rangeH, rangeS, rangeV;
bool using_white = false;
int thresh = 150;

std::vector<MatArea> api_traffic_sign_detection_visual(Mat& src, int visual_mode) {
    Mat blue, red, green, white;
    Mat dst, hsv, draw;
    std::vector<MatArea> tmp_traffic_sign;
    vector<MatArea> final_result;

    //normalize each range of color in the image to 1 color
    hsv = normalizeI(src);

    //create an image for drawing stuff
    src.copyTo(draw);

    //create red, green, blue mask for detection by color
    red = red_detector(hsv);
    blue = blue_detector(hsv);
    green = green_detector(hsv);

    //blur red, green, blue mask to remove noise
    GaussianBlur(blue, blue, Size(3, 3), 0, 0);
    GaussianBlur(red, red, Size(3, 3), 0, 0);
    GaussianBlur(green, green, Size(3, 3), 0, 0);

    extract_candidate(blue, src, hsv, draw, 'B', final_result);
    extract_candidate(red, src, hsv, draw, 'R', final_result);
    extract_candidate(green, src, hsv, draw, 'G', final_result);

    if (visual_mode == 2) {
        imshow("norm_img: ", convert(hsv));

    }else if(visual_mode == 3){
        imshow("after_white", draw);
    }

    //    cout << "noi" <<endl;

    return final_result;
}

void white_checkers(Mat src, Mat& draw, MatArea cropped, vector<MatArea>& temp_result, char color) {
    std::vector<std::vector<Point> > cnts;
    std::vector<Vec4i> hierarchy;

    vector<MatArea> final_result;

    Mat hsv_cropped = normalizeI(cropped.first);

    int cnt_stride = 3;

    Mat white = white_detector(hsv_cropped);
    GaussianBlur(white, white, Size(3, 3), 0, 0);

    if (color == 'R') {
        findContours(white, cnts, hierarchy, CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE, Point(3, 3));
    } else if (color == 'B') {
        findContours(white, cnts, hierarchy, CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE, Point(3, 3));
    } else if (color == 'G') {
        temp_result.push_back(cropped);
        return;
    }

    for (int i = 0; i < cnts.size(); i++) {
        std::vector<Point> cnt = cnts[i];
        Rect rect = boundingRect(cnt);

        rect.x += cropped.second.x;
        rect.y += cropped.second.y;

        int x = rect.x;
        int y = rect.y;
        int width = rect.width;
        int height = rect.height;
        int area = width*height;
        if (area < hsv_cropped.cols * hsv_cropped.rows / 10 || x + width > src.cols || y + height > src.rows) {
            continue;
        }

        //                    cout <<"x: "<<x<<endl;
        //                    cout <<"y: "<<y<<endl;
        //                    cout <<"width: "<<x+width<<endl;
        //                    cout <<"height: "<<y+height<<endl;

        Mat roi = src(rect);

        if (color == 'R') {
            if (!check_red(x, y, width, height, src, -0.1)) {
                continue;
            }
        }

        if (color == 'B') {
            if (!check_blue(x, y, width, height, src, -0.1)) {
                continue;
            }
        }

        //imshow("roi", roi);
        rectangle(draw, Point(x, y), Point(x + width, y + height), Scalar(0, 0, 0), 2);

        temp_result.push_back(std::make_pair(roi, rect));
    }

}

Mat blue_detector(Mat input) {
    Mat dst;
    cv::inRange(input, Scalar(100, 255, 255), Scalar(100, 255, 255), dst);
    return dst;
}

Mat white_detector(Mat input) {
    Mat dst;
    cv::inRange(input, Scalar(0, 0, 255), Scalar(0, 0, 255), dst);
    return dst;
}

Mat red_detector(Mat input) {
    Mat dst;
    cv::inRange(input, Scalar(179, 255, 255), Scalar(179, 255, 255), dst);
    return dst;
}

Mat green_detector(Mat input) {
    Mat dst;
    cv::inRange(input, Scalar(57, 255, 255), Scalar(57, 255, 255), dst);
    return dst;
}

//check if this cropped image contains blue and white pixel with some given ratio

bool check_blue(int x, int y, int width, int height, Mat input, double ratio) {

    Mat checkMatrix = Mat::zeros(Size(width, height), CV_8U);
    Mat croped = ROI(input, x, y, width, height);


    croped = normalizeI(croped.clone());

    Mat filted = white_detector(croped);

    float sum = 0;
    bool haveBlue = false;
    bool haveWhite = false;

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (filted.at<uchar>(i, j) == 255) {
                sum--;
                haveWhite = true;
            }
        }
    }

    filted = blue_detector(croped);
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (filted.at<uchar>(i, j) == 255) {
                sum++;
                haveBlue = true;
            }
        }
    }

    sum = sum / (height * width);

    if (haveBlue && sum > ratio) {
        return true;
    }
    return false;
}

//check if this cropped image contains red and white pixel with some given ratio
bool check_red(int x, int y, int width, int height, Mat input, double ratio) {

    Mat checkMatrix = Mat::zeros(Size(width, height), CV_8U);
    Mat croped = ROI(input, x, y, width, height);


    croped = normalizeI(croped.clone());

    Mat filted = white_detector(croped);

    float sum = 0;
    bool haveRed = false;
    bool haveWhite = false;

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (filted.at<uchar>(i, j) == 255) {
                sum--;
                haveWhite = true;
            }
        }
    }

    filted = red_detector(croped);
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (filted.at<uchar>(i, j) == 255) {
                sum++;
                haveRed = true;
            }
        }
    }

    sum = sum / (height * width);

    if (haveRed && sum > ratio) {
        return true;
    }
    return false;
}

//check if this cropped image contains green and white pixel with some given ratio

bool check_green(int x, int y, int width, int height, Mat input, double ratio) {

    Mat checkMatrix = Mat::zeros(Size(width, height), CV_8U);
    Mat croped = ROI(input, x, y, width, height);


    croped = normalizeI(croped.clone());

    Mat filted = white_detector(croped);

    float sum = 0;
    bool haveGreen = false;
    bool haveWhite = false;

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (filted.at<uchar>(i, j) == 255) {
                sum--;
                haveWhite = true;
            }
        }
    }

    filted = green_detector(croped);
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (filted.at<uchar>(i, j) == 255) {
                sum++;
                haveGreen = true;
            }
        }
    }

    sum = sum / (height * width);

    if (haveGreen && sum > ratio) {
        return true;
    }
    return false;
}

void extract_candidate(Mat mask, Mat& src, Mat hsv, Mat& draw, char color, std::vector<MatArea>& result) {
    std::vector<std::vector<Point> > cnts;
    std::vector<Vec4i> hierarchy;

    findContours(mask, cnts, hierarchy, RETR_EXTERNAL, 1, Point(0, 0));
    for (int i = 0; i < cnts.size(); i++) {
        std::vector<Point> cnt = cnts[i];
        Rect rect = boundingRect(cnt);

        int height = rect.height;
        int width = rect.width;
        int area = width * height;


        if (area < 19200 && area > 200 && abs(width - height) < 20) {
            int x = rect.x;
            int y = rect.y;

            if (x <= 0 || y <= 0 || x + width >= src.cols || y + height >= src.rows) {
                continue;
            }

            if (color == 'R') {
                if (!check_red(x, y, width, height, src, 0)) {
                    continue;
                }
            } else if (color == 'B') {
                if (!check_blue(x, y, width, height, src, -0.1)) {
                    continue;
                }
            } else if (color == 'G') {
                if (!check_green(x, y, width, height, src, 0.3)) {
                    continue;
                }

            }

            //            cout<<"raw: "<<raw.cols<<endl;
            //            cout <<"x: "<<x<<endl;
            //            cout <<"y: "<<y<<endl;
            //            cout <<"width: "<<x+width<<endl;
            //            cout <<"height: "<<y+height<<endl;
            //


            rectangle(hsv, Point(x, y), Point(x + width, y + height), Scalar(0, 0, 0), 2);

            MatArea mat_area;

            mat_area.first = ROI(src, x, y, width, height);
            mat_area.second = rect;

            if(using_white){
                 white_checkers(src, draw, mat_area, result, color);
            }else{
                result.push_back(mat_area);
            }

        }
    }

}

Mat ROI(Mat src, int x, int y, int width, int height) {
    return src(Rect(x, y, width, height));
}

Mat convert(Mat src) {
    Mat dst;
    cvtColor(src, dst, CV_HSV2BGR);
    return dst;
}

Mat normalizeI(const Mat& src) {
    int rangeH, rangeS, rangeV;
    Mat dst;
    //convert to hsv
    cvtColor(src, dst, CV_BGR2HSV);

    /*============DEFINE RANGE FOR HUE COLOR==============*/
    int max_hue = 179;
    int min_hue = 0;
    /*Lower thresh*/
    int l_yellow, l_green, l_blue, l_magneta, l_red;
    /*Upper thresh*/
    int h_yellow, h_green, h_blue, h_magneta, h_red;
    /*====================================================*/

    /*Specific range*/
    l_green = 35;
    h_green = 96;

    l_blue = 97;
    h_blue = 118;

    l_red = 169;
    h_red = 2;
    /*------------*/


    for (int y = 0; y < dst.rows; ++y) {
        for (int x = 0; x < dst.cols; ++x) {
            /*===================HUE PROCESSING==========================*/
            if (dst.at<Vec3b>(y, x)[0] >= l_green && dst.at<Vec3b>(y, x)[0] < h_green) {
                //Green
                rangeH = 57;
            } else if (dst.at<Vec3b>(y, x)[0] >= l_blue && dst.at<Vec3b>(y, x)[0] < h_blue) {
                //Blue
                rangeH = 100;
            } else if (dst.at<Vec3b>(y, x)[0] >= l_red || dst.at<Vec3b>(y, x)[0] < h_red) {
                //Red
                rangeH = 179;
            } else {
                dst.at<Vec3b>(y, x)[0] = 0;
                dst.at<Vec3b>(y, x)[1] = 0;
                dst.at<Vec3b>(y, x)[2] = 255;
            }
            dst.at<Vec3b>(y, x)[0] = rangeH;
            /*===================SATURATION + VALUE PROCESSING================*/

            if (dst.at<Vec3b>(y, x)[1] < thresh && dst.at<Vec3b>(y, x)[2] >= thresh) {
                //White case
                dst.at<Vec3b>(y, x)[0] = 0;
                rangeS = 0;
                rangeV = 255;
            } else if (dst.at<Vec3b>(y, x)[1] >= thresh && dst.at<Vec3b>(y, x)[2] >= thresh) {
                //Light Color case
                rangeS = 255;
                rangeV = 255;
            } else if (dst.at<Vec3b>(y, x)[1] >= thresh && dst.at<Vec3b>(y, x)[2] < thresh) {
                //Dark Color case
                rangeS = 255;
                rangeV = 255;
            } else {
                //Black case
                dst.at<Vec3b>(y, x)[0] = 0;
                rangeS = 0;
                rangeV = 255;
            }
            dst.at<Vec3b>(y, x)[1] = rangeS;
            dst.at<Vec3b>(y, x)[2] = rangeV;
            /*=================================================================*/

        }
    }

    return dst;
}
