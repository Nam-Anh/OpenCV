/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   traffic_sign_detection.h
 * Author: atheros
 *
 * Created on March 15, 2018, 6:02 PM
 */

//input: frame
//output: std::vector of candidate sign

#ifndef TRAFFIC_SIGN_DETECTION_H
#define TRAFFIC_SIGN_DETECTION_H

//include library here
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv;


typedef pair<Mat, Rect> MatArea;


//declare function prototype
Mat blue_detector(Mat src);
Mat white_detector(Mat src);
Mat red_detector(Mat src);
Mat green_detector(Mat src);

bool check_red(int x, int y, int width, int height, Mat input, double ratio);
bool check_blue(int x, int y, int width, int height, Mat input, double ratio);
bool check_green(int x, int y, int width, int height, Mat input, double ratio);

Mat ROI(Mat src,int x,int y,int width,int height);
std::vector<MatArea> extract_candidate_img(Mat src,Mat& raw,bool isRed);
std::vector<MatArea> api_traffic_sign_detection(Mat& src);

void extract_candidate(Mat mask, Mat& src, Mat hsv, Mat& draw,
        char color, std::vector<MatArea>& result);

std::vector<MatArea> api_traffic_sign_detection_visual(Mat& src, int visual_mode);
vector<MatArea> white_checker(Mat src, vector<MatArea>& temp_result);
void white_checkers(Mat src, MatArea cropped, vector<MatArea>& temp_result, char color);
#endif /* TRAFFIC_SIGN_DETECTION_H */

Mat test(Mat src);
Mat convert(Mat src);
Mat normalizeI(const Mat& src);

extern bool using_white;

extern int rangeH, rangeS, rangeV;
