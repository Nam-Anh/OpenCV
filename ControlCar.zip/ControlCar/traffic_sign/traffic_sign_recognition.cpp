#include "traffic_sign_recognition.h"

std::vector<Label_Area> evaluate_frame(Mat& frame, int visual_mode) {
    Rect stop_rect(-1, -1, 0, 0), left_right_rect(-1, -1, 0, 0), object_rect(-1, -1, 0, 0);
    Label_Area left_right, stop, object;

    left_right = std::make_pair(-1, left_right_rect);
    stop = std::make_pair(-1, stop_rect);
    object = std::make_pair(-1, object_rect);
    //cout <<object.second <<endl;
    std::vector<Label_Area> vec_label_area;


    std::vector<MatArea> detected_imgs = api_traffic_sign_detection_visual(frame, visual_mode);
    //return vec_label_area;
    //get max label
    double max_confidence = left_right_std_cnfdnce;

    int area_max = std_object_area;

    Prediction p_max;
    MatArea mat_area;

    //get the traffic sign which has the most confidence and the object having the largest area
    for (int i = 0; i < detected_imgs.size(); i++) {

        Prediction p = getLabel(detected_imgs[i].first);
//        cout << p.first << " "<<p.second <<endl;
//
        if (p.first == "2 stop") {
            if (p.second > stop_std_cnfdnce) {
                stop_rect = detected_imgs[i].second;
                stop = std::make_pair(2, stop_rect);
            }
        } else if (p.first == "0 turn_left_ahead" || p.first == "1 turn_right_ahead") {
            if (p.second > max_confidence) {
                p_max = p;
                max_confidence = p_max.second;
                left_right_rect = detected_imgs[i].second;
                if (p.first == "0 turn_left_ahead") {
                    left_right = std::make_pair(0, left_right_rect);
                } else {
                    left_right = std::make_pair(1, left_right_rect);
                }
            }
        } else {
            if (p.second > obj_std_cnfdnce) {
                Rect rect = detected_imgs[i].second;
                int area = rect.width * rect.height;
                if (area > area_max && area <  14400 ) {
                    area_max = area;
                    object_rect = rect;
                    object = std::make_pair(3, object_rect);
                }

            }
        }

    }

    if (visual_mode != 1) {
        //normalize object position
        if(object.second.x != -1) {
            object.second.x /= 2;
            object.second.y /= 2;
            object.second.width /= 2;
            object.second.height /= 2;
        }


        vec_label_area.push_back(left_right);
        vec_label_area.push_back(stop);
        vec_label_area.push_back(object);

        //cout << object.second <<endl;
        return vec_label_area;

    }

    //draw object bounding box to frame
    if (object.first != -1) {
        rectangle(frame, object_rect, Scalar(255, 255, 255));
        putText(frame, "object", Point(80, 60), FONT_HERSHEY_SIMPLEX, .7, Scalar(0, 0, 255), 2, 8, false);

        //normalize object position
        object.second.x /= 2;
        object.second.y /= 2;
        object.second.width /= 2;
        object.second.height /= 2;

    }


    //draw left-right traffic sign
    if (left_right.first != -1) {
        rectangle(frame, left_right_rect, Scalar(255, 255, 255));
        putText(frame, p_max.first, Point(80, 40), FONT_HERSHEY_SIMPLEX, .7, Scalar(0, 0, 255), 2, 8, false);
    }


    //draw stop
    if (stop.first != -1) {
        rectangle(frame, stop_rect, Scalar(255, 255, 255));
        putText(frame, "stop", Point(80, 20), FONT_HERSHEY_SIMPLEX, .7, Scalar(0, 0, 255), 2, 8, false);
    }


    vec_label_area.push_back(left_right);
    vec_label_area.push_back(stop);
    vec_label_area.push_back(object);


    imshow("Traffic Sign", frame);
    return vec_label_area;
}

