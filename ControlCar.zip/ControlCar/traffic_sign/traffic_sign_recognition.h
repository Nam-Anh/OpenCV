/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   traffic_sign_recognition.h
 * Author: atheros
 *
 */

#ifndef TRAFFIC_SIGN_RECOGNITION_H
#define TRAFFIC_SIGN_RECOGNITION_H

#include "traffic_sign_detection.h"
#include "traffic_sign_classify.h"

typedef std::pair<int, Rect> Label_Area;

//define const here
const int stack_times = 0;
const double left_right_std_cnfdnce = 0.8;
const double stop_std_cnfdnce = 0.8;
const double obj_std_cnfdnce = 0.8;
const int std_object_area = 3600;


int evaluate_frame(Mat& frame);
std::vector<Label_Area> evaluate_frame(Mat& frame, int visual_mode);

#endif /* TRAFFIC_SIGN_RECOGNITION_H */

