#include "video_logger.h"

VideoWriter color_writer;
VideoWriter gray_writer;
int codec = CV_FOURCC('D','I','V', 'X');
bool init_color_yet = false;
bool init_gray_yet = false;

void init_video_writer(Size gray_video_size) {
    color_writer.open(color_name, codec, 20, Size(640,480), true);
    gray_writer.open(gray_name, codec, 20, gray_video_size, true);
}
void log_color(Mat color){
    if (!init_color_yet){
        color_writer.open(color_name, codec, 20, color.size(), color.channels() == 3 ? true : false);
        init_color_yet = true;
    }
    color_writer.write(color);
}
void log_gray(Mat gray){
    if (!init_gray_yet){
        gray_writer.open(gray_name, codec, 20, gray.size(), gray.channels() == 3 ? true : false);
        init_gray_yet = true;
    }
    gray_writer.write(gray);
}
void release_video_writer() {
    if (color_writer.isOpened()){
        color_writer.release();
    }
    if (gray_writer.isOpened()){
        gray_writer.release();
    }
}
