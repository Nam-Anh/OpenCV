#ifndef VIDEO_LOGGER_H_INCLUDED
#define VIDEO_LOGGER_H_INCLUDED

#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;

const string color_name = "/home/ubuntu/Desktop/video_log/color.avi";
const string gray_name = "/home/ubuntu/Desktop/video_log/gray.avi";

extern VideoWriter color_writer;
extern VideoWriter gray_writer;
extern int codec;
extern bool init_color_yet;
extern bool init_gray_yet;

void init_video_writer(Size gray_video_size);
void log_color(Mat color);
void log_gray(Mat gray);
void release_video_writer();

#endif // VIDEO_LOGGER_H_INCLUDED
